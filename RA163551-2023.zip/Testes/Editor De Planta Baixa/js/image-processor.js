// js/image-processor.js (VERSÃO COM ARQUITETURA DE DEEP LEARNING)

import { dom } from './main.js';
import { finalizeStandaloneWall } from './drawing.js';
import { updateAllWallsAppearance } from './canvas.js';
import { gridSize } from './drawing.js';
// É preciso importar a biblioteca do TensorFlow.js no seu HTML principal
// <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@latest/dist/tf.min.js"></script>

// --- CONFIGURAÇÕES ---
let segmentationModel = null; // Variável para armazenar o modelo de IA carregado
const MODEL_URL = '/path/to/your/model/model.json'; // Caminho para o modelo treinado (formato TF.js)
const IMAGE_SIZE = 512; // Tamanho que o modelo de IA espera (ex: 512x512 pixels)

/**
 * Carrega o modelo de segmentação de IA na inicialização da página.
 * Deve ser chamado uma vez quando a aplicação começa.
 */
export async function initializeAIModel() {
    try {
        console.log("Carregando modelo de IA para análise de plantas...");
        segmentationModel = await tf.loadGraphModel(MODEL_URL);
        console.log("Modelo de IA carregado com sucesso!");
        // Aquece o modelo para a primeira inferência ser mais rápida
        const warmupTensor = tf.zeros([1, IMAGE_SIZE, IMAGE_SIZE, 3]);
        await segmentationModel.predict(warmupTensor).dispose();
        warmupTensor.dispose();
    } catch (error) {
        console.error("Falha ao carregar o modelo de IA:", error);
        alert("Não foi possível carregar o módulo de Inteligência Artificial. A análise de imagem estará desativada.");
    }
}

/**
 * Função principal que orquestra a análise usando o modelo de IA.
 */
export async function processImage(file) {
    if (!segmentationModel) {
        alert("O modelo de IA não está carregado. Aguarde ou recarregue a página.");
        return;
    }

    const imageUrl = URL.createObjectURL(file);
    const img = new Image();
    
    img.onload = async () => {
        document.body.style.cursor = 'wait';
        alert("Iniciando análise com Inteligência Artificial. Isso pode levar um momento...");
        
        try {
            // 1. A IA segmenta a imagem para encontrar as paredes
            const wallMask = await predictWallMask(img);
            
            // 2. As máscaras de pixels são convertidas em linhas vetoriais
            const rawLines = vectorizeMask(wallMask);
            
            // 3. (Opcional) Pós-processamento leve para unir linhas perfeitamente
            const cleanLines = postProcessVectorizedLines(rawLines);
            
            // 4. O OCR e cálculo de escala funcionam como antes, mas com dados muito melhores
            const ocrData = await runOCR(img); // O OCR pode usar a imagem original
            const pixelsPerMeter = findPixelsPerMeterRatio(cleanLines, ocrData);
            const scaleFactor = pixelsPerMeter ? gridSize / pixelsPerMeter : 1.0;
            
            // 5. Reconstrói o canvas com os dados precisos
            rebuildCanvasFromAnalysis(cleanLines, scaleFactor);
            alert("Análise com IA concluída!");
        } catch (error) {
            console.error("Erro na análise com IA:", error);
            alert("Ocorreu um erro durante a análise. Verifique o console.");
        } finally {
            document.body.style.cursor = 'default';
            URL.revokeObjectURL(imageUrl);
        }
    };
    img.src = imageUrl;
}

/**
 * Usa o modelo de IA para prever a máscara de paredes na imagem.
 * @param {HTMLImageElement} imgElement
 * @returns {cv.Mat} Uma matriz do OpenCV representando a máscara de paredes.
 */
async function predictWallMask(imgElement) {
    console.log("Pré-processando imagem para o modelo...");
    // tf.browser.fromPixels converte a imagem para um Tensor
    const tensor = tf.browser.fromPixels(imgElement)
        .resizeNearestNeighbor([IMAGE_SIZE, IMAGE_SIZE]) // Redimensiona para o tamanho esperado pelo modelo
        .toFloat()
        .expandDims(); // Adiciona uma dimensão de batch

    console.log("Executando inferência do modelo de IA...");
    const prediction = await segmentationModel.predict(tensor);
    
    // Processa a saída do modelo para criar uma máscara binária
    const [height, width] = prediction.shape.slice(1, 3);
    const mask = tf.squeeze(prediction).argMax(2).asType('int32'); // Pega a classe com maior probabilidade por pixel
    
    // Converte o tensor da máscara para uma matriz do OpenCV para vetorização
    const maskData = await mask.data();
    const maskMat = new cv.Mat(height, width, cv.CV_8UC1);
    const wallClassIndex = 1; // Supondo que a classe 'parede' seja o índice 1
    
    for (let i = 0; i < height * width; ++i) {
        maskMat.data[i] = maskData[i] === wallClassIndex ? 255 : 0;
    }

    // Limpeza de memória do TensorFlow
    tensor.dispose();
    prediction.dispose();
    mask.dispose();
    
    // Redimensiona a máscara para o tamanho original da imagem
    let finalMask = new cv.Mat();
    cv.resize(maskMat, finalMask, new cv.Size(imgElement.width, imgElement.height), 0, 0, cv.INTER_NEAREST);
    maskMat.delete();

    return finalMask;
}

/**
 * Converte a máscara de pixels binária em segmentos de linha (vetores).
 * Esta função substitui completamente o antigo `findAndCleanLines`.
 * @param {cv.Mat} wallMask - A máscara de paredes gerada pela IA.
 * @returns {Array} Um array de objetos de linha.
 */
function vectorizeMask(wallMask) {
    // Usa a detecção de contornos do OpenCV, que é muito eficaz em máscaras binárias
    let contours = new cv.MatVector();
    let hierarchy = new cv.Mat();
    cv.findContours(wallMask, contours, hierarchy, cv.RETR_CCOMP, cv.CHAIN_APPROX_SIMPLE);
    
    let lines = [];
    for (let i = 0; i < contours.size(); ++i) {
        let contour = contours.get(i);
        // Aproxima o contorno a um polígono para obter linhas retas
        let approx = new cv.Mat();
        cv.approxPolyDP(contour, approx, 3, true); // O '3' é a tolerância de aproximação
        
        for (let j = 0; j < approx.rows - 1; j++) {
            const p1 = { x: approx.data32S[j * 2], y: approx.data32S[j * 2 + 1] };
            const p2 = { x: approx.data32S[(j + 1) * 2], y: approx.data32S[(j + 1) * 2 + 1] };
            
            // Adiciona a linha (com verificação para ser horizontal ou vertical)
             const angle = Math.abs(Math.atan2(p2.y - p1.y, p2.x - p1.x) * 180 / Math.PI);
            if (angle < 5 || angle > 175) { // Horizontal
                lines.push({ x1: Math.min(p1.x, p2.x), y1: (p1.y + p2.y) / 2, x2: Math.max(p1.x, p2.x), y2: (p1.y + p2.y) / 2, orientation: 'horizontal' });
            } else if (Math.abs(angle - 90) < 5) { // Vertical
                lines.push({ x1: (p1.x + p2.x) / 2, y1: Math.min(p1.y, p2.y), x2: (p1.x + p2.x) / 2, y2: Math.max(p1.y, p2.y), orientation: 'vertical' });
            }
        }
        contour.delete();
        approx.delete();
    }
    
    contours.delete();
    hierarchy.delete();
    
    return lines;
}

// Funções como `runOCR`, `findPixelsPerMeterRatio`, `rebuildCanvasFromAnalysis` podem ser mantidas,
// pois se beneficiarão da entrada de dados muito mais limpa vinda da IA.
// A função `postProcessLines` pode ser simplificada ou removida.

// (Cole aqui as implementações anteriores de runOCR, findPixelsPerMeterRatio e rebuildCanvasFromAnalysis)
// ...