// js/data.js (VERSÃO COM ANÁLISE DE IMAGEM)

import { dom } from './main.js';
import { finalizeStandaloneWall } from './drawing.js';
import { updateAllWallsAppearance } from './canvas.js';
// LINHA ADICIONADA
import { processImage } from './image-processor.js';

const saveBtn = document.getElementById('saveBtn');
const loadBtn = document.getElementById('loadBtn');
const clearBtn = document.getElementById('clearBtn');
const fileInput = document.getElementById('fileInput');

// BLOCO ADICIONADO
const loadImageBtn = document.getElementById('loadImageBtn');
const imageFileInput = document.getElementById('imageFileInput');
// FIM DO BLOCO ADICIONADO

export function initDataHandlers() {
    saveBtn.addEventListener('click', saveData);
    loadBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', loadData);
    clearBtn.addEventListener('click', () => {
        if (confirm("Você tem certeza que deseja limpar tudo?")) {
            dom.canvas.innerHTML = '';
        }
    });

    // BLOCO ADICIONADO
    if (loadImageBtn && imageFileInput) {
        loadImageBtn.addEventListener('click', () => imageFileInput.click());
        imageFileInput.addEventListener('change', (event) => {
            const file = event.target.files[0];
            if (file) {
                if (confirm("Isso limpará o projeto atual para analisar a imagem. Deseja continuar?")) {
                    processImage(file);
                }
            }
            imageFileInput.value = '';
        });
    }
    // FIM DO BLOCO ADICIONADO
}

function saveData() {
    const planData = {
        walls: [],
        gridSize: 20
    };

    document.querySelectorAll('.standalone-wall').forEach(wallEl => {
        const wallData = {
            id: wallEl.id,
            name: wallEl.dataset.name || '',
            left: wallEl.offsetLeft,
            top: wallEl.offsetTop,
            width: wallEl.offsetWidth,
            height: wallEl.offsetHeight,
            orientation: wallEl.dataset.orientation,
            objects: []
        };
         wallEl.querySelectorAll('.wall-object').forEach(objEl => {
            wallData.objects.push({
                type: objEl.classList.contains('door') ? 'door' : 'window',
                orientation: objEl.dataset.orientation,
                left: objEl.offsetLeft,
                top: objEl.offsetTop,
                width: objEl.offsetWidth,
                height: objEl.offsetHeight
            });
        });
        planData.walls.push(wallData);
    });

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(planData, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "planta-baixa.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
}

function loadData(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            rebuildCanvas(data);
        } catch (error) {
            console.error("Erro ao carregar o arquivo JSON:", error);
            alert("Não foi possível carregar o arquivo. Verifique se é um JSON válido.");
        }
    };
    reader.readAsText(file);
    fileInput.value = '';
}

function rebuildCanvas(data) {
    dom.canvas.innerHTML = '';
    if (data.walls) {
        data.walls.forEach(wallData => {
            const wallEl = document.createElement('div');
            wallEl.dataset.orientation = wallData.orientation;
            wallEl.style.left = `${wallData.left}px`;
            wallEl.style.top = `${wallData.top}px`;
            wallEl.style.width = `${wallData.width}px`;
            wallEl.style.height = `${wallData.height}px`;
            
            const options = {
                id: wallData.id,
                name: wallData.name,
                objects: wallData.objects
            };

            dom.canvas.appendChild(wallEl);
            finalizeStandaloneWall(wallEl, options);
        });
    }
    updateAllWallsAppearance();
}