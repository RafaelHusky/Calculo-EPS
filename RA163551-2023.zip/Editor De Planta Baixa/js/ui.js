import { state, setState, dom } from './main.js';
import { updateAllWallsAppearance, updateStandaloneWallAppearance } from './canvas.js';
import { duplicateWall, gridSize } from './drawing.js';

const toolBtns = document.querySelectorAll('.tool-btn');
const themeToggleBtn = document.getElementById('theme-toggle');
const propertiesPanel = document.getElementById('properties-panel');
const elementNameInput = document.getElementById('element-name-input');
const elementLengthInput = document.getElementById('element-length-input');

export function initUI() {
    toolBtns.forEach(btn => {
        if (btn.dataset.tool) {
            btn.addEventListener('click', () => setTool(btn.dataset.tool));
        }
    });

    // --- AQUI ESTÁ A CORREÇÃO ---
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', toggleTheme);
    }
    // ---------------------------
    
    dom.contextMenu.addEventListener('click', onContextMenuClick);

    elementNameInput.addEventListener('input', () => {
        const activeEl = state.activeElement;
        if (!activeEl) return;
        activeEl.dataset.name = elementNameInput.value;
        const nameSpan = activeEl.querySelector('.element-name');
        if (nameSpan) {
            nameSpan.textContent = elementNameInput.value;
            nameSpan.style.display = elementNameInput.value ? 'block' : 'none';
        }
    });

    elementLengthInput.addEventListener('change', () => {
        const activeEl = state.activeElement;
        if (!activeEl || !activeEl.classList.contains('standalone-wall')) return;
        
        const newLengthM = parseFloat(elementLengthInput.value);
        if (isNaN(newLengthM) || newLengthM < 0.1) {
            updatePropertiesPanel(activeEl);
            return;
        }
        
        const newLengthPx = (newLengthM / 0.1) * gridSize;
        
        if (activeEl.dataset.orientation === 'horizontal') {
            activeEl.style.width = `${newLengthPx}px`;
        } else {
            activeEl.style.height = `${newLengthPx}px`;
        }
        updateStandaloneWallAppearance(activeEl);
    });

    const savedTheme = localStorage.getItem('theme');
    const initialTheme = savedTheme || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    applyTheme(initialTheme);

    setTool('pointer');
}

export function setTool(tool) {
    setState({ currentTool: tool });
    toolBtns.forEach(btn => {
        const isActive = btn.dataset.tool === tool;
        btn.classList.toggle('active', isActive);
    });
    dom.canvasContainer.style.cursor = (tool === 'pointer') ? 'grab' : 'crosshair';
}

export function selectElement(element) {
    document.querySelectorAll('.selected').forEach(el => el.classList.remove('selected'));
    setState({ activeElement: element });

    if (element) {
        element.classList.add('selected');
    }
    updateAllWallsAppearance();
    updatePropertiesPanel(element);
}

function updatePropertiesPanel(element) {
    if (!element || !element.classList.contains('standalone-wall')) {
        propertiesPanel.classList.add('hidden');
        return;
    }
    propertiesPanel.classList.remove('hidden');

    elementNameInput.value = element.dataset.name || '';

    const isHorizontal = element.dataset.orientation === 'horizontal';
    const lengthPx = isHorizontal ? element.offsetWidth : element.offsetHeight;
    const lengthM = (lengthPx / gridSize / 10).toFixed(2);
    elementLengthInput.value = lengthM;
}

export function hideContextMenu() {
    dom.contextMenu.classList.add('hidden');
    setState({ activeContextMenuObj: null });
}

export function showWallContextMenu(e, wall) {
    e.stopPropagation();
    hideContextMenu();
    setState({ activeContextMenuObj: wall });
    const itemsHtml = `
        <div class="context-menu-item" data-action="duplicate">Duplicar</div>
        <div class="context-menu-item text-red-600" data-action="delete">Excluir</div>
    `;
    dom.contextMenu.innerHTML = itemsHtml;
    Object.assign(dom.contextMenu.style, { left: `${e.clientX + 10}px`, top: `${e.clientY}px` });
    dom.contextMenu.classList.remove('hidden');
}

export function showSizeEditor(e) {
    e.stopPropagation();
    hideContextMenu();
    setState({ activeContextMenuObj: e.currentTarget });
    dom.contextMenu.innerHTML = `<div class="context-menu-item text-red-600" data-action="delete">Excluir</div>`;
    Object.assign(dom.contextMenu.style, { left: `${e.clientX + 10}px`, top: `${e.clientY}px` });
    dom.contextMenu.classList.remove('hidden');
}

function onContextMenuClick(e) {
    e.stopPropagation();
    const item = e.target.closest('.context-menu-item');
    if (!item || !state.activeContextMenuObj) return;
    const action = item.dataset.action;

    if (action === 'delete') {
        state.activeContextMenuObj.remove();
        selectElement(null);
    } else if (action === 'duplicate') {
        duplicateWall(state.activeContextMenuObj);
    }
    hideContextMenu();
}

// Função toggleTheme com lógica mais explícita
function toggleTheme() {
    const currentTheme = document.documentElement.classList.contains('dark') ? 'dark' : 'light';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('theme', newTheme);
    applyTheme(newTheme);
}

// Função applyTheme mais robusta para evitar problemas de cache/estado
function applyTheme(theme) {
    const isDark = theme === 'dark';
    
    // Garante que a classe 'dark' seja removida antes de qualquer outra ação.
    // Isso é mais seguro do que usar classList.toggle() neste contexto.
    document.documentElement.classList.remove('dark');
    if (isDark) {
        document.documentElement.classList.add('dark');
    }
    
    // Gerencia a visibilidade dos ícones de tema
    const themeIconLight = document.getElementById('theme-icon-light');
    const themeIconDark = document.getElementById('theme-icon-dark');
    if (themeIconLight && themeIconDark) {
        themeIconLight.classList.toggle('hidden', isDark);
        themeIconDark.classList.toggle('hidden', !isDark);
    }

    updateAllWallsAppearance();
    
    const currentActiveToolBtn = document.querySelector('.tool-btn.active');
    if (currentActiveToolBtn) {
        setTool(currentActiveToolBtn.dataset.tool);
    }
}