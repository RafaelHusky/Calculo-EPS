// js/canvas.js (VERSÃO FINAL CORRIGIDA)

import { state, dom } from './main.js'; // <<< ADICIONADO: Importar 'dom' diretamente

let scale = 1.0;
let panX = 0;
let panY = 0;

/**
 * Inicializa os controles de zoom do canvas.
 */
export function initCanvas() {
    // Acessa 'dom' diretamente, não através de 'state.dom'
    dom.canvasContainer.addEventListener('wheel', handleWheel, { passive: false });
}

// --- Funções de Get/Set ---

export function getScale() { return scale; }
export function getPan() { return { panX, panY }; }
export function setPan(x, y) {
    panX = x;
    panY = y;
}

/**
 * Aplica a transformação de pan e zoom ao elemento canvas.
 */
export function applyTransform() {
    // Acessa 'dom' diretamente
    dom.canvas.style.transform = `translate(${panX}px, ${panY}px) scale(${scale})`;
}

/**
 * Lida com o evento de rolagem do mouse para aplicar zoom.
 * @param {WheelEvent} e
 */
function handleWheel(e) {
    e.preventDefault();
    // Acessa 'dom' diretamente
    const rect = dom.canvasContainer.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const zoomFactor = e.deltaY < 0 ? 1.1 : 1 / 1.1;
    const newScale = Math.max(0.2, Math.min(scale * zoomFactor, 3));

    // Calcula o novo pan para que o zoom seja centrado no mouse
    panX = mouseX - (mouseX - panX) * (newScale / scale);
    panY = mouseY - (mouseY - panY) * (newScale / scale);
    scale = newScale;

    applyTransform();
    updateAllWallsAppearance();
}


// --- Funções de Aparência ---

/**
 * Atualiza a aparência de todas as paredes (ex: espessura ao dar zoom).
 */
export function updateAllWallsAppearance() {
    document.querySelectorAll('.standalone-wall').forEach(updateStandaloneWallAppearance);
}

/**
 * Atualiza a aparência de uma parede específica.
 * @param {HTMLElement} wall
 */
export function updateStandaloneWallAppearance(wall) {
    if (!wall) return;
    const wallThickness = 4 / scale;
    const isHorizontal = wall.dataset.orientation === 'horizontal';

    if (isHorizontal) {
        wall.style.height = `${wallThickness}px`;
    } else {
        wall.style.width = `${wallThickness}px`;
    }
    
    // Atualiza posição do nome
    const nameSpan = wall.querySelector('.element-name');
    if (nameSpan) {
        nameSpan.style.bottom = `${wallThickness + 5 / scale}px`;
        nameSpan.style.fontSize = `${14 / scale}px`;
    }

    // Atualiza objetos na parede
    wall.querySelectorAll('.wall-object').forEach(obj => {
        const isObjHorizontal = obj.dataset.orientation === 'horizontal';
        const wallObjThicknessPx = 8 / scale;

        if (isObjHorizontal) {
            obj.style.height = `${wallObjThicknessPx}px`;
            obj.style.top = `${(wallThickness / 2) - (wallObjThicknessPx / 2)}px`;
        } else { // Vertical
            obj.style.width = `${wallObjThicknessPx}px`;
            obj.style.left = `${(wallThickness / 2) - (wallObjThicknessPx / 2)}px`;
        }
    });
}