// js/controls.js (VERSÃO CORRIGIDA E CONSOLIDADA)

import { state, setState, dom } from './main.js';
import { getScale, getPan, setPan, applyTransform, updateStandaloneWallAppearance } from './canvas.js';
import { finalizeStandaloneWall, placeWallObject, duplicateWall, gridSize } from './drawing.js';
import { setTool, selectElement, hideContextMenu } from './ui.js';

let isPanning = false;
let panStart = { x: 0, y: 0 };

export function initControls() {
    dom.canvasContainer.addEventListener('mousedown', onCanvasMouseDown);
    dom.canvasContainer.addEventListener('mousemove', onCanvasMouseMove);
    window.addEventListener('mouseup', onWindowMouseUp);
    window.addEventListener('keydown', handleKeyDown);
}

// --- Handlers do Canvas ---

function onCanvasMouseDown(e) {
    if (!e.target.closest('.context-menu-item')) hideContextMenu();
    if (e.target !== dom.canvasContainer && e.target !== dom.canvas) return;

    const { panX, panY } = getPan();
    const scale = getScale();
    const containerRect = dom.canvasContainer.getBoundingClientRect();
    const canvasX = (e.clientX - containerRect.left - panX) / scale;
    const canvasY = (e.clientY - containerRect.top - panY) / scale;

    if (state.currentTool === 'wall') {
        if (!state.isDrawingWall) {
            setState({ isDrawingWall: true });
            // Snap para a grade no início do desenho
            const startPos = { 
                x: Math.round(canvasX / gridSize) * gridSize, 
                y: Math.round(canvasY / gridSize) * gridSize 
            };
            setState({ wallStartPos: startPos });

            const preview = document.createElement('div');
            preview.className = 'standalone-wall preview';
            preview.style.top = `${startPos.y}px`;
            preview.style.left = `${startPos.x}px`;
            dom.canvas.appendChild(preview);
            setState({ previewWall: preview });
        } else {
            finalizeStandaloneWall(state.previewWall);
            setState({ previewWall: null, isDrawingWall: false });
            setTool('pointer');
        }
    } else if (state.currentTool === 'pointer') {
        selectElement(null);
        if (e.button === 0) {
            isPanning = true;
            panStart.x = e.clientX - panX;
            panStart.y = e.clientY - panY;
            dom.canvasContainer.style.cursor = 'grabbing';
        }
    }
}

function onCanvasMouseMove(e) {
    if (isPanning) {
        const newPanX = e.clientX - panStart.x;
        const newPanY = e.clientY - panStart.y;
        setPan(newPanX, newPanY);
        applyTransform();
    } else if (state.isDrawingWall && state.previewWall) {
        const { panX, panY } = getPan();
        const scale = getScale();
        const containerRect = dom.canvasContainer.getBoundingClientRect();
        const canvasX = (e.clientX - containerRect.left - panX) / scale;
        const canvasY = (e.clientY - containerRect.top - panY) / scale;
        
        // Snap para a grade durante o desenho
        const endX = Math.round(canvasX / gridSize) * gridSize;
        const endY = Math.round(canvasY / gridSize) * gridSize;

        const dx = endX - state.wallStartPos.x;
        const dy = endY - state.wallStartPos.y;
        const wallThickness = 4 / scale;

        if (Math.abs(dx) > Math.abs(dy)) {
            state.previewWall.style.left = `${Math.min(state.wallStartPos.x, endX)}px`;
            state.previewWall.style.top = `${state.wallStartPos.y - wallThickness / 2}px`;
            state.previewWall.style.width = `${Math.abs(dx)}px`;
            state.previewWall.style.height = `${wallThickness}px`;
            state.previewWall.dataset.orientation = 'horizontal';
        } else {
            state.previewWall.style.left = `${state.wallStartPos.x - wallThickness / 2}px`;
            state.previewWall.style.top = `${Math.min(state.wallStartPos.y, endY)}px`;
            state.previewWall.style.width = `${wallThickness}px`;
            state.previewWall.style.height = `${Math.abs(dy)}px`;
            state.previewWall.dataset.orientation = 'vertical';
        }
    }
}

function onWindowMouseUp() {
    if (isPanning) {
        isPanning = false;
        dom.canvasContainer.style.cursor = 'grab';
    }
}

// --- Handlers dos Elementos ---

export function onStandaloneWallMouseDown(e) {
    e.stopPropagation();
    hideContextMenu();
    clearMergeHandles();
    const wall = e.currentTarget;
    if (state.currentTool === 'door' || state.currentTool === 'window') {
        placeWallObject(wall, e, state.currentTool);
        return;
    }
    selectElement(wall);
    let action = 'move';
    if (e.target.classList.contains('wall-resize-handle')) {
        action = e.target.classList.contains('start') ? 'resize-wall-start' : 'resize-wall-end';
    }
    setState({ action });
    const initialMouse = { x: e.clientX, y: e.clientY };
    const initialPos = { left: wall.offsetLeft, top: wall.offsetTop };
    const initialSize = { width: wall.offsetWidth, height: wall.offsetHeight };
    document.onmousemove = (moveEvent) => onElementMouseMove(moveEvent, initialMouse, initialPos, initialSize);
    document.onmouseup = onElementMouseUp;
}

export function onWallObjectMouseDown(e) {
    e.stopPropagation();
    hideContextMenu();
    const obj = e.currentTarget;
    selectElement(obj);
    if (state.currentTool !== 'pointer') return;
    
    setState({ action: 'move-wall-object' });
    const initialMouse = { x: e.clientX, y: e.clientY };
    const initialPos = { left: obj.offsetLeft, top: obj.offsetTop };
    document.onmousemove = (moveEvent) => onElementMouseMove(moveEvent, initialMouse, initialPos, null);
    document.onmouseup = onElementMouseUp;
}

function onElementMouseMove(e, initialMouse, initialPos, initialSize) {
    if (!state.activeElement) return;
    const scale = getScale();
    const dx = (e.clientX - initialMouse.x) / scale;
    const dy = (e.clientY - initialMouse.y) / scale;
    
    switch (state.action) {
        case 'move':
            state.activeElement.style.left = `${initialPos.left + dx}px`;
            state.activeElement.style.top = `${initialPos.top + dy}px`;
            break;
        case 'resize-wall-start':
            if (state.activeElement.dataset.orientation === 'horizontal') {
                state.activeElement.style.left = `${initialPos.left + dx}px`;
                state.activeElement.style.width = `${initialSize.width - dx}px`;
            } else {
                state.activeElement.style.top = `${initialPos.top + dy}px`;
                state.activeElement.style.height = `${initialSize.height - dy}px`;
            }
            break;
        case 'resize-wall-end':
             if (state.activeElement.dataset.orientation === 'horizontal') {
                state.activeElement.style.width = `${initialSize.width + dx}px`;
            } else {
                state.activeElement.style.height = `${initialSize.height + dy}px`;
            }
            break;
        case 'move-wall-object':
            const obj = state.activeElement;
            const wall = obj.parentElement;
            if (obj.dataset.orientation === 'horizontal') {
                let newLeft = initialPos.left + dx;
                const minLeft = 0;
                const maxLeft = wall.clientWidth - obj.offsetWidth;
                obj.style.left = `${Math.max(minLeft, Math.min(newLeft, maxLeft))}px`;
            } else {
                let newTop = initialPos.top + dy;
                const minTop = 0;
                const maxTop = wall.clientHeight - obj.offsetHeight;
                obj.style.top = `${Math.max(minTop, Math.min(newTop, maxTop))}px`;
            }
            break;
    }
}

function onElementMouseUp() {
    document.onmousemove = null;
    document.onmouseup = null;

    if (state.activeElement && state.activeElement.classList.contains('standalone-wall')) {
        // ADICIONADO: Lógica de "snap to grid" ao soltar o mouse
        const wall = state.activeElement;
        wall.style.left = `${Math.round(wall.offsetLeft / gridSize) * gridSize}px`;
        wall.style.top = `${Math.round(wall.offsetTop / gridSize) * gridSize}px`;

        if (wall.dataset.orientation === 'horizontal') {
            wall.style.width = `${Math.round(wall.offsetWidth / gridSize) * gridSize}px`;
        } else {
            wall.style.height = `${Math.round(wall.offsetHeight / gridSize) * gridSize}px`;
        }

        checkForMergeableWalls(state.activeElement);
        selectElement(state.activeElement); // Re-seleciona para atualizar o painel de propriedades
    }
    setState({ action: null });
}

function handleKeyDown(e) {
    if (document.activeElement.tagName === 'INPUT') return;

    if (e.key === 'Delete' || e.key === 'Backspace') {
        if (state.activeElement) {
            state.activeElement.remove();
            selectElement(null);
        }
    }
    if (e.ctrlKey && e.key.toLowerCase() === 'c') {
        if (state.activeElement && state.activeElement.classList.contains('standalone-wall')) {
            setState({ clipboard: state.activeElement });
        }
    }
    if (e.ctrlKey && e.key.toLowerCase() === 'v') {
        if (state.clipboard) {
            duplicateWall(state.clipboard);
        }
    }
}

// --- Lógica de Fusão de Paredes ---

function clearMergeHandles() {
    document.querySelectorAll('.merge-handle').forEach(handle => handle.remove());
}

function checkForMergeableWalls(movedWall) {
    clearMergeHandles();
    const allWalls = document.querySelectorAll('.standalone-wall');
    const tolerance = 8;

    allWalls.forEach(otherWall => {
        if (movedWall.id === otherWall.id || movedWall.dataset.orientation !== otherWall.dataset.orientation) return;
        
        const isHorizontal = movedWall.dataset.orientation === 'horizontal';
        const isCollinear = isHorizontal ?
            Math.abs(movedWall.offsetTop - otherWall.offsetTop) < tolerance :
            Math.abs(movedWall.offsetLeft - otherWall.offsetLeft) < tolerance;

        if (isCollinear) {
            let mergePoint = null;
            if (isHorizontal) {
                if (Math.abs((movedWall.offsetLeft + movedWall.offsetWidth) - otherWall.offsetLeft) < tolerance) {
                    mergePoint = { x: movedWall.offsetLeft + movedWall.offsetWidth, y: movedWall.offsetTop + movedWall.offsetHeight / 2 };
                } else if (Math.abs(movedWall.offsetLeft - (otherWall.offsetLeft + otherWall.offsetWidth)) < tolerance) {
                    mergePoint = { x: movedWall.offsetLeft, y: movedWall.offsetTop + movedWall.offsetHeight / 2 };
                }
            } else { // Vertical
                if (Math.abs((movedWall.offsetTop + movedWall.offsetHeight) - otherWall.offsetTop) < tolerance) {
                    mergePoint = { x: movedWall.offsetLeft + movedWall.offsetWidth / 2, y: movedWall.offsetTop + movedWall.offsetHeight };
                } else if (Math.abs(movedWall.offsetTop - (otherWall.offsetTop + otherWall.offsetHeight)) < tolerance) {
                    mergePoint = { x: movedWall.offsetLeft + movedWall.offsetWidth / 2, y: movedWall.offsetTop };
                }
            }
            if (mergePoint) createMergeHandle(mergePoint, movedWall, otherWall);
        }
    });
}

function createMergeHandle(point, wall1, wall2) {
    const handle = document.createElement('div');
    handle.className = 'merge-handle';
    handle.dataset.wall1Id = wall1.id;
    handle.dataset.wall2Id = wall2.id;
    handle.style.left = `${point.x}px`;
    handle.style.top = `${point.y}px`;
    handle.addEventListener('click', mergeWallsAction);
    dom.canvas.appendChild(handle);
}

function mergeWallsAction(event) {
    const handle = event.target;
    const wall1 = document.getElementById(handle.dataset.wall1Id);
    const wall2 = document.getElementById(handle.dataset.wall2Id);
    if (!wall1 || !wall2 || wall1.dataset.orientation !== wall2.dataset.orientation) return;

    const isHorizontal = wall1.dataset.orientation === 'horizontal';
    
    // Lógica simplificada e mais correta
    const newLeft = Math.min(wall1.offsetLeft, wall2.offsetLeft);
    const newTop = Math.min(wall1.offsetTop, wall2.offsetTop);
    
    const newWidth = isHorizontal 
        ? Math.max(wall1.offsetLeft + wall1.offsetWidth, wall2.offsetLeft + wall2.offsetWidth) - newLeft
        : wall1.offsetWidth;
        
    const newHeight = isHorizontal 
        ? wall1.offsetHeight
        : Math.max(wall1.offsetTop + wall1.offsetHeight, wall2.offsetTop + wall2.offsetHeight) - newTop;

    wall1.style.left = `${newLeft}px`;
    wall1.style.top = `${newTop}px`;
    wall1.style.width = `${newWidth}px`;
    wall1.style.height = `${newHeight}px`;

    wall2.remove();
    handle.remove();
    updateStandaloneWallAppearance(wall1);
    selectElement(wall1);
}