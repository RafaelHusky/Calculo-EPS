// js/main.js (VERSÃO FINAL)

import { initCanvas, applyTransform, updateAllWallsAppearance } from './canvas.js';
import { initControls } from './controls.js';
import { initUI } from './ui.js';
import { initDataHandlers } from './data.js';

export let state = {
    activeElement: null,
    action: null,
    currentTool: 'pointer',
    activeContextMenuObj: null,
    isDrawingWall: false,
    wallStartPos: { x: 0, y: 0 },
    previewWall: null,
    clipboard: null
};

export const dom = {
    canvasContainer: document.getElementById('canvas-container'),
    canvas: document.getElementById('canvas'),
    contextMenu: document.getElementById('context-menu'),
};

export function setState(newState) {
    state = { ...state, ...newState };
}

window.addEventListener('DOMContentLoaded', () => {
    initUI();
    initDataHandlers();
    initCanvas();
    initControls();

    applyTransform();
    updateAllWallsAppearance();
});