// js/image-processor.js (VERSÃO COM ESCALA AUTOMÁTICA OCR)

import { dom } from './main.js';
import { finalizeStandaloneWall } from './drawing.js';
import { updateAllWallsAppearance } from './canvas.js';
import { gridSize } from './drawing.js';

/**
 * Função principal, agora assíncrona para aguardar o OCR.
 */
export async function processImage(file) {
    const imageUrl = URL.createObjectURL(file);
    const img = new Image();
    
    img.onload = async () => {
        // Verifica se as bibliotecas estão prontas
        if (typeof cv === 'undefined' || typeof Tesseract === 'undefined') {
            alert('As bibliotecas de análise ainda não carregaram. Tente novamente em alguns segundos.');
            URL.revokeObjectURL(imageUrl);
            return;
        }

        // Adiciona um feedback visual de que o processamento começou
        document.body.style.cursor = 'wait';
        alert("Iniciando análise automática. Este processo pode levar alguns segundos...");

        try {
            const planData = await analyzeImageAndAutoScale(img);
            rebuildCanvasFromAnalysis(planData);
            alert("Análise concluída!");
        } catch (error) {
            console.error("Erro ao processar imagem:", error);
            alert("Ocorreu um erro ao analisar a imagem. Verifique o console para mais detalhes.");
        } finally {
            // Limpa o cursor e a URL do objeto
            document.body.style.cursor = 'default';
            URL.revokeObjectURL(imageUrl);
        }
    };
    img.src = imageUrl;
}

/**
 * Orquestra a análise de linhas e o OCR para gerar a planta em escala.
 * @param {HTMLImageElement} imgElement
 */
async function analyzeImageAndAutoScale(imgElement) {
    // 1. Encontra as linhas (paredes) na imagem, da mesma forma que antes
    const cleanedLines = findAndCleanLines(imgElement);

    // 2. Executa o OCR para encontrar todos os números na imagem
    console.log("Executando OCR para ler as medidas...");
    const ocrData = await runOCR(imgElement);
    console.log(`OCR encontrou ${ocrData.length} números.`);

    // 3. O "coração" da automação: associa os números às paredes e encontra a escala
    console.log("Calculando a escala a partir dos dados...");
    const pixelsPerMeter = findPixelsPerMeterRatio(cleanedLines, ocrData);
    
    if (!pixelsPerMeter) {
        alert("Não foi possível determinar a escala automaticamente. A planta será desenhada sem escala.");
    } else {
         console.log(`Escala determinada: ${pixelsPerMeter.toFixed(2)} pixels por metro.`);
    }

    const scaleFactor = pixelsPerMeter ? gridSize / pixelsPerMeter : 1.0;

    // 4. Gera os dados da planta, já aplicando a escala encontrada
    const planData = { walls: [] };
    cleanedLines.forEach(line => {
        planData.walls.push({
            orientation: line.orientation,
            left: line.x1 * scaleFactor,
            top: line.y1 * scaleFactor,
            width: (line.x2 - line.x1) * scaleFactor,
            height: (line.y2 - line.y1) * scaleFactor,
        });
    });

    return planData;
}

/**
 * Executa o Tesseract.js na imagem para extrair números e suas posições.
 * @returns {Promise<Array>} Uma lista de objetos { number, bbox }
 */
async function runOCR(imgElement) {
    const result = await Tesseract.recognize(imgElement, 'eng', {
        logger: m => console.log(m), // Mostra o progresso no console
        tessedit_char_whitelist: '0123456789.,', // Reconhece apenas números, ponto e vírgula
    });

    return result.data.words
        .map(word => {
            const number = parseFloat(word.text.replace(',', '.'));
            if (!isNaN(number) && number > 0.1) { // Ignora números muito pequenos
                return { number, bbox: word.bbox };
            }
            return null;
        })
        .filter(Boolean); // Remove os nulos
}

/**
 * A LÓGICA DE ASSOCIAÇÃO: Encontra a relação pixels/metro mais provável.
 * @param {Array} lines - Linhas limpas da detecção do OpenCV.
 * @param {Array} ocrData - Dados extraídos do OCR.
 * @returns {number|null} A quantidade de pixels por metro, ou null se não for encontrada.
 */
function findPixelsPerMeterRatio(lines, ocrData) {
    const potentialRatios = [];
    const MAX_DISTANCE = 50; // Distância máxima (em pixels) para associar um número a uma parede

    for (const data of ocrData) {
        const num = data.number;
        const textCenterX = data.bbox.x0 + (data.bbox.x1 - data.bbox.x0) / 2;
        const textCenterY = data.bbox.y0 + (data.bbox.y1 - data.bbox.y0) / 2;

        let bestCandidate = { line: null, distance: Infinity };

        for (const line of lines) {
            const lineLength = line.orientation === 'horizontal' ? line.x2 - line.x1 : line.y2 - line.y1;
            const lineCenterX = line.x1 + (line.x2 - line.x1) / 2;
            const lineCenterY = line.y1 + (line.y2 - line.y1) / 2;

            // Heurística de associação: o texto deve estar próximo e alinhado com a parede
            let distance;
            if (line.orientation === 'horizontal' && textCenterX > line.x1 && textCenterX < line.x2) {
                distance = Math.abs(textCenterY - lineCenterY);
            } else if (line.orientation === 'vertical' && textCenterY > line.y1 && textCenterY < line.y2) {
                distance = Math.abs(textCenterX - lineCenterX);
            } else {
                continue; // Pula se não estiver alinhado
            }
            
            if (distance < MAX_DISTANCE && distance < bestCandidate.distance) {
                bestCandidate = { line, distance };
            }
        }

        if (bestCandidate.line) {
            const lineLength = bestCandidate.line.orientation === 'horizontal' 
                ? bestCandidate.line.x2 - bestCandidate.line.x1 
                : bestCandidate.line.y2 - bestCandidate.line.y1;
            
            // Calcula a proporção de pixels por metro para esta associação
            const ratio = lineLength / num;
            potentialRatios.push(ratio);
        }
    }

    if (potentialRatios.length === 0) return null;

    // Lógica para encontrar a proporção mais confiável: agrupa proporções similares e pega a média do maior grupo
    potentialRatios.sort((a, b) => a - b);
    let bestGroup = [];
    let currentGroup = [];
    for (const ratio of potentialRatios) {
        if (currentGroup.length === 0 || Math.abs(ratio - currentGroup[0]) < 10) { // Tolera uma variação de 10px
            currentGroup.push(ratio);
        } else {
            if (currentGroup.length > bestGroup.length) {
                bestGroup = currentGroup;
            }
            currentGroup = [ratio];
        }
    }
    if (currentGroup.length > bestGroup.length) {
        bestGroup = currentGroup;
    }

    // Retorna a média do grupo mais consistente de proporções
    return bestGroup.reduce((sum, r) => sum + r, 0) / bestGroup.length;
}


// --- Funções Auxiliares (movidas de `analyzeImage` para serem reutilizáveis) ---

function findAndCleanLines(imgElement) {
    let src = cv.imread(imgElement);
    let gray = new cv.Mat();
    let edges = new cv.Mat();
    let linesMat = new cv.Mat();
    cv.cvtColor(src, gray, cv.COLOR_RGBA2GRAY, 0);
    cv.GaussianBlur(gray, gray, new cv.Size(5, 5), 0, 0, cv.BORDER_DEFAULT);
    cv.Canny(gray, edges, 50, 150, 3);
    cv.HoughLinesP(edges, linesMat, 1, Math.PI / 180, 50, 30, 10);
    let rawLines = [];
    for (let i = 0; i < linesMat.rows; ++i) {
        const x1 = linesMat.data32S[i * 4], y1 = linesMat.data32S[i * 4 + 1], x2 = linesMat.data32S[i * 4 + 2], y2 = linesMat.data32S[i * 4 + 3];
        if (Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2)) < 20) continue;
        const isHorizontal = Math.abs(y1 - y2) < 5, isVertical = Math.abs(x1 - x2) < 5;
        if (isHorizontal) rawLines.push({ x1: Math.min(x1, x2), y1: (y1 + y2) / 2, x2: Math.max(x1, x2), y2: (y1 + y2) / 2, orientation: 'horizontal' });
        else if (isVertical) rawLines.push({ x1: (x1 + x2) / 2, y1: Math.min(y1, y2), x2: (x1 + x2) / 2, y2: Math.max(y1, y2), orientation: 'vertical' });
    }
    src.delete(); gray.delete(); edges.delete(); linesMat.delete();
    return postProcessLines(rawLines);
}

function postProcessLines(lines) {
    let mergedLines = [], used = new Array(lines.length).fill(false);
    for (let i = 0; i < lines.length; i++) {
        if (used[i]) continue;
        let cluster = [lines[i]]; used[i] = true;
        for (let j = i + 1; j < lines.length; j++) {
            if (used[j] || lines[i].orientation !== lines[j].orientation) continue;
            if ((lines[i].orientation === 'horizontal' && Math.abs(lines[i].y1 - lines[j].y1) < 10) || (lines[i].orientation === 'vertical' && Math.abs(lines[i].x1 - lines[j].x1) < 10)) {
                cluster.push(lines[j]); used[j] = true;
            }
        }
        let avgLine;
        if (cluster[0].orientation === 'horizontal') {
            const avgY = cluster.reduce((sum, line) => sum + line.y1, 0) / cluster.length, minX = Math.min(...cluster.map(l => l.x1)), maxX = Math.max(...cluster.map(l => l.x2));
            avgLine = { x1: minX, y1: avgY, x2: maxX, y2: avgY, orientation: 'horizontal' };
        } else {
            const avgX = cluster.reduce((sum, line) => sum + line.x1, 0) / cluster.length, minY = Math.min(...cluster.map(l => l.y1)), maxY = Math.max(...cluster.map(l => l.y2));
            avgLine = { x1: avgX, y1: minY, x2: avgX, y2: maxY, orientation: 'vertical' };
        }
        mergedLines.push(avgLine);
    }
    let connectedLines = [], used2 = new Array(mergedLines.length).fill(false);
    for (let i = 0; i < mergedLines.length; i++) {
        if (used2[i]) continue;
        let baseLine = { ...mergedLines[i] }; used2[i] = true;
        for (let j = i + 1; j < mergedLines.length; j++) {
            if (used2[j] || baseLine.orientation !== mergedLines[j].orientation) continue;
            let lineB = mergedLines[j];
            if (baseLine.orientation === 'horizontal' && Math.abs(baseLine.y1 - lineB.y1) < 5) {
                if (baseLine.x2 >= lineB.x1 - 25 && baseLine.x1 <= lineB.x2 + 25) { baseLine.x1 = Math.min(baseLine.x1, lineB.x1); baseLine.x2 = Math.max(baseLine.x2, lineB.x2); used2[j] = true; }
            } else if (baseLine.orientation === 'vertical' && Math.abs(baseLine.x1 - lineB.x1) < 5) {
                if (baseLine.y2 >= lineB.y1 - 25 && baseLine.y1 <= lineB.y2 + 25) { baseLine.y1 = Math.min(baseLine.y1, lineB.y1); baseLine.y2 = Math.max(baseLine.y2, lineB.y2); used2[j] = true; }
            }
        }
        connectedLines.push(baseLine);
    }
    return connectedLines;
}

function rebuildCanvasFromAnalysis(data) {
    dom.canvas.innerHTML = '';
    if (data.walls) {
        data.walls.forEach(wallData => {
            // As paredes já vêm escaladas, apenas garantimos que não sejam muito finas
            const width = wallData.orientation === 'vertical' ? 4 : wallData.width;
            const height = wallData.orientation === 'horizontal' ? 4 : wallData.height;

            if (width < 1 || height < 1) return; // Não desenha paredes "invisíveis"

            const wallEl = document.createElement('div');
            wallEl.dataset.orientation = wallData.orientation;
            wallEl.style.left = `${wallData.left}px`;
            wallEl.style.top = `${wallData.top}px`;
            wallEl.style.width = `${width}px`;
            wallEl.style.height = `${height}px`;
            
            dom.canvas.appendChild(wallEl);
            finalizeStandaloneWall(wallEl);
        });
    }
    updateAllWallsAppearance();
}