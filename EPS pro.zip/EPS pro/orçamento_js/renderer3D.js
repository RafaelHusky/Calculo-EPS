// Importa os elementos do DOM necessários do módulo UI
import { 
    preview3DContainer, 
    placeholder3D,
    epsEspessuraInput,
    rebocoEspessuraInput
} from './ui.js';

// Variáveis da cena 3D (nível do módulo)
let scene, camera, renderer, controls, structureGroup;

/**
 * Inicializa a cena 3D do Three.js, câmara, luzes e controlos.
 * Só é executado uma vez.
 */
export function initThree() {
    if (scene) return; // Já inicializado

    // 1. Cena
    scene = new THREE.Scene();
    const isDark = document.documentElement.classList.contains('dark');
    scene.background = new THREE.Color(isDark ? 0x020617 : 0xf1f5f9); // Cor escura atualizada

    // 2. Câmara
    camera = new THREE.PerspectiveCamera(50, preview3DContainer.clientWidth / preview3DContainer.clientHeight, 0.1, 1000);
    
    // 3. Luzes
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(10, 20, 5);
    scene.add(directionalLight);

    // 4. Renderizador
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    preview3DContainer.appendChild(renderer.domElement);
    
    // 5. Controlos
    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;

    // 6. Grupo para a estrutura
    structureGroup = new THREE.Group();
    scene.add(structureGroup);

    // 7. Loop de Animação
    function animate() {
        requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
    }
    animate();
}

/**
 * Lida com o redimensionamento da janela e atualiza a câmara e o renderizador.
 */
export function onWindowResize() {
    if (!camera || !renderer || !preview3DContainer) return;
    const { clientWidth, clientHeight } = preview3DContainer;
    
    if (clientWidth > 0 && clientHeight > 0) {
        camera.aspect = clientWidth / clientHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(clientWidth, clientHeight);
    }
}

/**
 * Limpa todos os objetos da cena 3D, libertando a memória.
 */
function clearScene() {
    if (!structureGroup) return;
    while (structureGroup.children.length > 0) {
        const object = structureGroup.children[0];
        structureGroup.remove(object);
        
        // Limpa geometria e materiais
        if(object.traverse) {
            object.traverse(child => {
                if (child.isMesh) {
                    if (child.geometry) child.geometry.dispose();
                    if (child.material) {
                        if (Array.isArray(child.material)) {
                            child.material.forEach(material => material.dispose());
                        } else {
                            child.material.dispose();
                        }
                    }
                }
            });
        }
    }
}

/**
 * Foca a câmara no centro de um objeto ou grupo.
 * @param {THREE.Object3D} targetObject - O grupo ou malha a focar.
 */
function focusCameraOn(targetObject) {
    const box = new THREE.Box3().setFromObject(targetObject);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z);
    
    const fov = camera.fov * (Math.PI / 180);
    const cameraDist = Math.abs(maxDim / Math.tan(fov / 2)) * 1.2;
    
    controls.reset();
    controls.target.copy(center);
    camera.position.copy(center);
    camera.position.z += cameraDist;
    camera.position.y += cameraDist * 0.6;
    controls.update();
}

/**
 * Cria a malha 3D para uma única parede, incluindo buracos.
 * (Função privada do módulo)
 */
function createWallMesh(wallData, pixelToMeter, wallHeight) {
    const wallLength = (wallData.orientation === 'horizontal' ? wallData.width : wallData.height) * pixelToMeter;
    const wallThickness = (parseFloat(epsEspessuraInput.value) + 2 * parseFloat(rebocoEspessuraInput.value)) / 100;
    
    const halfLength = wallLength / 2;
    const halfHeight = wallHeight / 2;

    const wallShape = new THREE.Shape();
    wallShape.moveTo(-halfLength, -halfHeight);
    wallShape.lineTo(halfLength, -halfHeight);
    wallShape.lineTo(halfLength, halfHeight);
    wallShape.lineTo(-halfLength, halfHeight);
    wallShape.lineTo(-halfLength, -halfHeight);

    // Cria buracos (janelas/portas)
    const holes = (wallData.objects || []).map(obj => {
        const path = new THREE.Path();

        // CORREÇÃO: Usa a propriedade correta (width/height, left/top) com base na orientação do *objeto*
        const isObjHorizontal = obj.orientation === 'horizontal';
        const holeW = (isObjHorizontal ? obj.width : obj.height) * pixelToMeter;
        const holePos = (isObjHorizontal ? obj.left : obj.top) * pixelToMeter;

        const holeH = (obj.type === 'door' ? 2.1 : 1.2); // Altura padrão da abertura
        const holeX = holePos - halfLength; // Posição X relativa ao centro da parede
        const holeY = (obj.type === 'door' ? 0 : 0.9) - halfHeight; // Posição Y relativa ao centro

        path.moveTo(holeX, holeY);
        path.lineTo(holeX + holeW, holeY);
        path.lineTo(holeX + holeW, holeY + holeH);
        path.lineTo(holeX, holeY + holeH);
        path.lineTo(holeX, holeY);
        return path;
    });
    wallShape.holes = holes;

    const extrudeSettings = { depth: wallThickness, bevelEnabled: false };
    const geometry = new THREE.ExtrudeGeometry(wallShape, extrudeSettings);
    geometry.translate(0, 0, -wallThickness / 2); // Centraliza a extrusão

    const isDarkMode = document.documentElement.classList.contains('dark');
    const material = new THREE.MeshStandardMaterial({ color: isDarkMode ? 0x94a3b8 : 0xcccccc });
    const mesh = new THREE.Mesh(geometry, material);
    
    return mesh;
}

/**
 * Desenha a estrutura 3D completa com base nos dados da planta.
 * Esta é a função principal de desenho 3D.
 * @param {object} planData - O objeto JSON da planta baixa carregado.
 * @param {number} pixelToMeter - O fator de conversão de píxeis para metros.
 * @param {number} wallHeight - A altura da parede (pé-direito) em metros.
 */
export function drawComplete3DStructure(planData, pixelToMeter, wallHeight) {
    if (!planData || !scene) return;
    
    initThree(); // Garante que está inicializado
    clearScene();
    
    placeholder3D.classList.add('hidden');

    // Calcula o centro da estrutura para centralizar na cena
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    planData.walls.forEach(wall => {
        minX = Math.min(minX, wall.left);
        minY = Math.min(minY, wall.top);
        maxX = Math.max(maxX, wall.left + wall.width);
        maxY = Math.max(maxY, wall.top + wall.height);
    });
    const structureCenterX = minX + (maxX - minX) / 2;
    const structureCenterY = minY + (maxY - minY) / 2;

    planData.walls.forEach(wall => {
        const wallMesh = createWallMesh(wall, pixelToMeter, wallHeight);
        
        // Posição 2D (planta baixa)
        const wallCenterX_pixels = wall.left + wall.width / 2;
        const wallCenterY_pixels = wall.top + wall.height / 2;

        // Posição 3D (mundo)
        const posX = (wallCenterX_pixels - structureCenterX) * pixelToMeter;
        const posZ = (wallCenterY_pixels - structureCenterY) * pixelToMeter; // Y da planta é Z no 3D

        wallMesh.position.set(posX, wallHeight / 2, posZ); // Põe a base em Y=0
        
        if (wall.orientation === 'vertical') {
            wallMesh.rotation.y = Math.PI / 2; // Rotaciona paredes verticais
        }

        structureGroup.add(wallMesh);
    });
    
    if (structureGroup.children.length > 0) {
        focusCameraOn(structureGroup);
    }
}

/**
 * Atualiza a cor de fundo (céu) da cena 3D.
 * @param {boolean} isDarkMode - Se o modo escuro está ativo.
 */
export function update3DSkyColor(isDarkMode) {
    if (scene) {
        scene.background.set(isDarkMode ? 0x020617 : 0xf1f5f9);
    }
}