// Importa o contexto do canvas 2D do módulo UI
import { previewCtx, previewCanvas } from './ui.js';

/**
 * Desenha o preview 2D da planta baixa no canvas.
 * @param {object} data - O objeto JSON da planta baixa carregado.
 */
export function drawPlanPreview(data) {
    const canvas = previewCanvas;
    const ctx = previewCtx;

    // Atraso de 10ms para garantir que o canvas tenha dimensões
    setTimeout(() => {
        if (!canvas.offsetWidth || !canvas.offsetHeight) return;
        
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        
        const isDarkMode = document.documentElement.classList.contains('dark');
        const allElements = data.walls || [];
        
        if (allElements.length === 0) { 
            ctx.clearRect(0, 0, canvas.width, canvas.height); 
            return; 
        };

        // Encontra os limites do desenho
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        allElements.forEach(el => {
            minX = Math.min(minX, el.left);
            minY = Math.min(minY, el.top);
            maxX = Math.max(maxX, el.left + el.width);
            maxY = Math.max(maxY, el.top + el.height);
        });

        const drawingWidth = maxX - minX;
        const drawingHeight = maxY - minY;
        
        // Calcula a escala para caber no canvas com padding
        const padding = 20;
        const scale = Math.min(
            (canvas.width - padding * 2) / drawingWidth, 
            (canvas.height - padding * 2) / drawingHeight
        );

        // Calcula o offset para centralizar o desenho
        const offsetX = (canvas.width - drawingWidth * scale) / 2 - minX * scale;
        const offsetY = (canvas.height - drawingHeight * scale) / 2 - minY * scale;

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.save();
        ctx.translate(offsetX, offsetY);
        ctx.scale(scale, scale);

        // Define as cores com base no modo (dark/light)
        const wallColor = isDarkMode ? '#94a3b8' : '#475569';
        const doorColor = isDarkMode ? '#fbbf24' : '#f59e0b';
        const windowColor = isDarkMode ? '#7dd3fc' : '#38bdf8';

        (data.walls || []).forEach(wall => {
            ctx.fillStyle = wallColor;
            ctx.fillRect(wall.left, wall.top, wall.width, wall.height);
            
            (wall.objects || []).forEach(obj => {
                ctx.fillStyle = obj.type === 'door' ? doorColor : windowColor;
                ctx.fillRect(wall.left + obj.left, wall.top + obj.top, obj.width, obj.height);
            });
        });

        ctx.restore();
    }, 10); // O atraso de 10ms ajuda a prevenir corridas de renderização
}