// =================================================================================
// SEÇÃO 1: SELEÇÃO DE ELEMENTOS DO DOM
// =================================================================================
// Exportamos todos os elementos para que 'main.js' possa adicionar-lhes 'event listeners'

export const uploadButton = document.getElementById('upload-button');
export const fileInput = document.getElementById('file-input');
export const calculateBtn = document.getElementById('calculateBtn');
export const modeToggle = document.getElementById('mode-toggle');
export const resultsDiv = document.getElementById('results');
export const previewCanvas = document.getElementById('planPreviewCanvas');
export const elevationsGrid = document.getElementById('elevations-grid');
export const themeIcon = document.getElementById('theme-icon');
export const previewCtx = previewCanvas.getContext('2d');
export const epsEspessuraInput = document.getElementById('epsEspessura');
export const rebocoEspessuraInput = document.getElementById('rebocoEspessura');
export const thicknessPreviewContainer = document.getElementById('thickness-preview-container');
export const toggleRebarBtn = document.getElementById('toggleRebarBtn');
export const toggleMeshBtn = document.getElementById('toggleMeshBtn');
export const toggle3DBtn = document.getElementById('toggle-3d-btn');
export const preview2DContainer = document.getElementById('preview-2d-container');
export const preview3DContainer = document.getElementById('preview-3d-container');
export const placeholder3D = document.getElementById('placeholder-3d');
export const previewTitle = document.getElementById('preview-title');
export const uploadStatus = document.getElementById('upload-status'); // <-- CORREÇÃO 1: ADICIONADO

// Ícones
const sunIcon = `<path d="M12 1v2m0 18v2M4.22 4.22l1.42 1.42m12.72 12.72l1.42 1.42M1 12h2m18 0h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/><circle cx="12" cy="12" r="5"/>`;
const moonIcon = `<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>`;

// =================================================================================
// SEÇÃO 2: FUNÇÕES DE ATUALIZAÇÃO DA UI (Exportadas)
// =================================================================================

/**
 * Exibe os resultados do cálculo e o orçamento detalhado.
 * @param {object} data - O objeto contendo quantitativos, custos, precos, netWallArea, e wallArea.
 */
export function displayResults(data) {
    const { quantitativos, custos, precos, netWallArea, wallArea } = data;
    resultsDiv.innerHTML = `
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div class="result-card card p-6 rounded-lg shadow-lg text-center">
                <h4 class="font-semibold">Painéis EPS</h4>
                <p class="text-2xl font-bold mt-2">${Math.ceil(quantitativos.epsPanels)}</p>
                <p class="text-sm text-slate-500 dark:text-slate-400">unidades</p>
            </div>
            <div class="result-card card p-6 rounded-lg shadow-lg text-center">
                <h4 class="font-semibold">Argamassa</h4>
                <p class="text-2xl font-bold mt-2">${quantitativos.rebocoVolume.toFixed(3)} m³</p>
                <p class="text-sm text-slate-500 dark:text-slate-400">volume total</p>
            </div>
            <div class="result-card card p-6 rounded-lg shadow-lg text-center">
                <h4 class="font-semibold">Malha de Aço</h4>
                <p class="text-2xl font-bold mt-2">${quantitativos.malhaArea.toFixed(2)} m²</p>
                <p class="text-sm text-slate-500 dark:text-slate-400">área total</p>
            </div>
        </div>
        <div class="card p-6 rounded-lg shadow-lg mt-4">
            <h2 class="text-2xl font-bold mb-4">Orçamento Detalhado</h2>
            <p class="text-sm text-slate-500 dark:text-slate-400 mb-4">Baseado em uma área líquida de parede de <strong>${netWallArea.toFixed(2)} m²</strong> (Área Bruta: ${wallArea.toFixed(2)} m²).</p>
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left">
                    <thead class="bg-slate-100 dark:bg-slate-800">
                        <tr>
                            <th class="p-3 font-semibold">Item</th>
                            <th class="p-3 font-semibold text-right">Qtd.</th>
                            <th class="p-3 font-semibold text-right">Preço Unit.</th>
                            <th class="p-3 font-semibold text-right">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="border-b border-slate-200 dark:border-slate-700">
                            <td class="p-3">Painel EPS</td>
                            <td class="p-3 text-right">${Math.ceil(quantitativos.epsPanels)} un</td>
                            <td class="p-3 text-right">R$ ${precos.painelEPS.toFixed(2)}</td>
                            <td class="p-3 text-right font-medium">R$ ${custos.custoEps.toFixed(2)}</td>
                        </tr>
                        <tr class="border-b border-slate-200 dark:border-slate-700">
                            <td class="p-3">Cimento (saco 50kg)</td>
                            <td class="p-3 text-right">${Math.ceil(quantitativos.qtdCimento)} un</td>
                            <td class="p-3 text-right">R$ ${precos.cimento.toFixed(2)}</td>
                            <td class="p-3 text-right font-medium">R$ ${custos.custoCimento.toFixed(2)}</td>
                        </tr>
                        <tr class="border-b border-slate-200 dark:border-slate-700">
                            <td class="p-3">Areia Média</td>
                            <td class="p-3 text-right">${quantitativos.qtdAreia.toFixed(2)} m³</td>
                            <td class="p-3 text-right">R$ ${precos.areia.toFixed(2)}</td>
                            <td class="p-3 text-right font-medium">R$ ${custos.custoAreia.toFixed(2)}</td>
                        </tr>
                        <tr class="border-b border-slate-200 dark:border-slate-700">
                            <td class="p-3">Brita 0</td>
                            <td class="p-3 text-right">${quantitativos.qtdBrita.toFixed(2)} m³</td>
                            <td class="p-3 text-right">R$ ${precos.brita.toFixed(2)}</td>
                            <td class="p-3 text-right font-medium">R$ ${custos.custoBrita.toFixed(2)}</td>
                        </tr>
                        <tr class="border-b border-slate-200 dark:border-slate-700">
                            <td class="p-3">Malha de Aço</td>
                            <td class="p-3 text-right">${quantitativos.malhaArea.toFixed(2)} m²</td>
                            <td class="p-3 text-right">R$ ${precos.malha.toFixed(2)}</td>
                            <td class="p-3 text-right font-medium">R$ ${custos.custoMalha.toFixed(2)}</td>
                        </tr>
                        <tr class="border-b border-slate-200 dark:border-slate-700">
                            <td class="p-3">Aditivo Plastificante</td>
                            <td class="p-3 text-right">${quantitativos.qtdAditivo.toFixed(2)} L</td>
                            <td class="p-3 text-right">R$ ${precos.aditivo.toFixed(2)}</td>
                            <td class="p-3 text-right font-medium">R$ ${custos.custoAditivo.toFixed(2)}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="mt-4 text-right">
                <p class="text-slate-500 dark:text-slate-400">Custo Total Estimado (Materiais):</p>
                <p class="text-3xl font-bold text-green-600">R$ ${custos.custoTotal.toFixed(2)}</p>
            </div>
        </div>`;
}

/**
 * Desenha as elevações das paredes no DOM.
 */
export function drawWallElevations(walls, wallHeight, pixelToMeter, panelWidth, panelHeight, vergalhoesVaoCm) {
    elevationsGrid.innerHTML = '';
    if (walls.length === 0) {
        elevationsGrid.innerHTML = '<p class="text-slate-500 dark:text-slate-400 md:col-span-2">Nenhuma parede para exibir.</p>';
        return;
    }

    const isDarkMode = document.documentElement.classList.contains('dark');
    const rebarLineColor = 'rgba(0, 0, 0, 0.8)';
    const panelLineColor = 'rgba(255, 255, 255, 0.5)';
    const meshLineColor = isDarkMode ? 'rgba(134, 239, 172, 0.4)' : 'rgba(22, 163, 74, 0.6)';

    walls.forEach(wall => {
        if (wall.length <= 0) return;

        // <-- CORREÇÃO 2: INÍCIO
        // Determina a orientação da parede atual
        const isWallHorizontal = wall.orientation === 'horizontal';
        // <-- CORREÇÃO 2: FIM

        const container = document.createElement('div');
        container.className = 'border border-slate-200 dark:border-slate-700 rounded-md p-3';
        const title = document.createElement('p');
        title.className = 'text-center font-medium text-sm mb-2';
        title.textContent = `${wall.name} (${wall.length.toFixed(2)}m)`;
        const elevationContainer = document.createElement('div');
        elevationContainer.className = 'w-full h-48 bg-slate-50 dark:bg-slate-900 rounded relative border border-slate-300 dark:border-slate-700 overflow-hidden'; // Cor de fundo atualizada
        
        // Malha (SVG)
        const meshPatternSize = 25;
        const meshSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        meshSvg.setAttribute('width', '100%');
        meshSvg.setAttribute('height', '100%');
        meshSvg.setAttribute('class', 'diagonal-mesh-svg hidden');
        meshSvg.style.cssText = 'position:absolute; z-index:15;';
        meshSvg.innerHTML = `<defs><pattern id="diagonalPattern" patternUnits="userSpaceOnUse" width="${meshPatternSize}" height="${meshPatternSize}"><path d="M0,0 l${meshPatternSize},${meshPatternSize} M${meshPatternSize},0 l-${meshPatternSize},${meshPatternSize}" stroke="${meshLineColor}" stroke-width="0.7"/></pattern></defs><rect width="100%" height="100%" fill="url(#diagonalPattern)"/>`;
        elevationContainer.appendChild(meshSvg);

        // Vergalhões (Linhas)
        const rebarSpacingMeters = vergalhoesVaoCm / 100;
        if (rebarSpacingMeters > 0) {
            for (let i = 1; i <= Math.floor(wall.length / rebarSpacingMeters); i++) {
                const line = document.createElement('div');
                line.className = 'rebar-line hidden';
                line.style.cssText = `position:absolute; top:0; height:100%; width:1px; background-color:${rebarLineColor}; left:${(i * rebarSpacingMeters / wall.length) * 100}%; z-index:20;`;
                elevationContainer.appendChild(line);
            }
            for (let i = 1; i <= Math.floor(wallHeight / rebarSpacingMeters); i++) {
                const line = document.createElement('div');
                line.className = 'rebar-line hidden';
                line.style.cssText = `position:absolute; left:0; width:100%; height:1px; background-color:${rebarLineColor}; top:${(i * rebarSpacingMeters / wallHeight) * 100}%; z-index:20;`;
                elevationContainer.appendChild(line);
            }
        }

        // Painéis (Linhas)
        if (panelWidth > 0) { for (let i = 1; i < Math.ceil(wall.length / panelWidth); i++) { const line = document.createElement('div'); line.style.cssText = `position:absolute; top:0; width:1px; height:100%; background-color: ${panelLineColor}; left:${(i * panelWidth / wall.length) * 100}%; z-index:10;`; elevationContainer.appendChild(line); } }
        if (panelHeight > 0 && wallHeight > 0) { for (let i = 1; i < Math.ceil(wallHeight / panelHeight); i++) { const line = document.createElement('div'); line.style.cssText = `position:absolute; left:0; height:1px; width:100%; background-color: ${panelLineColor}; top:${(i * panelHeight / wallHeight) * 100}%; z-index:10;`; elevationContainer.appendChild(line); } }
        
        // Portas e Janelas
        wall.objects.forEach(obj => {
            const objLengthInMeters = obj.objLength;

            // <-- CORREÇÃO 2: INÍCIO
            // Pega a posição correta (left/top) com base na orientação da PAREDE
            const objPosInPixels = isWallHorizontal ? obj.pos : obj.top;
            const objPosInMeters = objPosInPixels * pixelToMeter;
            // <-- CORREÇÃO 2: FIM
            
            const objDiv = document.createElement('div');
            
            // Posição (left) é baseada na posição ao longo do comprimento da parede
            const leftPercentage = (objPosInMeters / wall.length) * 100;
            const widthPercentage = (objLengthInMeters / wall.length) * 100;
            
            objDiv.style.cssText = `position:absolute; z-index:30; left:${leftPercentage}%; width:${widthPercentage}%;`;
            
            if (obj.type === 'door') {
                const h = (2.1 / wallHeight) * 100;
                objDiv.style.height = `${h > 100 ? 100 : h}%`;
                objDiv.style.bottom = '0';
                objDiv.className = 'bg-yellow-500/80 dark:bg-yellow-400/80 border-2 border-yellow-700 dark:border-yellow-600';
            } else { // window
                const h = (1.2 / wallHeight) * 100;
                const b = (0.9 / wallHeight) * 100;
                objDiv.style.height = `${h > 100 ? 100 : h}%`;
                objDiv.style.bottom = `${b}%`;
                objDiv.className = 'bg-sky-400/80 dark:bg-sky-300/80 border-2 border-sky-600 dark:border-sky-500';
            }
            elevationContainer.appendChild(objDiv);
        });

        container.appendChild(title);
        container.appendChild(elevationContainer);
        elevationsGrid.appendChild(container);
    });
}

/**
 * Desenha o preview da espessura da parede.
 */
export function drawThicknessPreview() {
    const epsCm = parseFloat(epsEspessuraInput.value) || 0;
    const rebocoCm = parseFloat(rebocoEspessuraInput.value) || 0;
    const totalCm = rebocoCm + epsCm + rebocoCm;
    if (totalCm <= 0) {
        thicknessPreviewContainer.innerHTML = '';
        return;
    }
    const rebocoPerc = (rebocoCm / totalCm) * 100;
    const epsPerc = (epsCm / totalCm) * 100;
    thicknessPreviewContainer.innerHTML = `
        <div class="flex flex-col h-full text-center justify-center">
            <div class="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">Espessura Total: ${totalCm.toFixed(1)} cm</div>
            <div class="flex-grow flex items-center w-full h-8 rounded overflow-hidden border border-slate-200 dark:border-slate-700">
                <div class="preview-bar bg-slate-400 dark:bg-slate-600" style="width: ${rebocoPerc}%" title="Reboco: ${rebocoCm} cm"><span>${rebocoCm}</span></div>
                <div class="preview-bar bg-sky-400 dark:bg-sky-500" style="width: ${epsPerc}%" title="EPS: ${epsCm} cm"><span>${epsCm}</span></div>
                <div class="preview-bar bg-slate-400 dark:bg-slate-600" style="width: ${rebocoPerc}%" title="Reboco: ${rebocoCm} cm"><span>${rebocoCm}</span></div>
            </div>
        </div>`;
}

/**
 * Inicializa o tema (dark/light) com base no localStorage ou preferência do sistema.
 */
export function initializeTheme() {
    if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark');
        themeIcon.innerHTML = sunIcon;
    } else {
        document.documentElement.classList.remove('dark');
        themeIcon.innerHTML = moonIcon;
    }
}

/**
 * Logica para alternar o modo escuro.
 */
export function handleModeToggle() {
    const isDarkMode = document.documentElement.classList.toggle('dark');
    themeIcon.innerHTML = isDarkMode ? sunIcon : moonIcon;
    localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
    return isDarkMode;
}

/**
 * Lógica para alternar a visibilidade dos vergalhões.
 */
export function handleRebarToggle() {
    const allRebarLines = document.querySelectorAll('.rebar-line');
    if (allRebarLines.length === 0) return;
    const isCurrentlyVisible = !allRebarLines[0].classList.contains('hidden');
    allRebarLines.forEach(line => line.classList.toggle('hidden', isCurrentlyVisible));
    const newVisibilityState = !isCurrentlyVisible;
    toggleRebarBtn.textContent = newVisibilityState ? 'Ocultar Vergalhões' : 'Mostrar Vergalhões';
    toggleRebarBtn.classList.toggle('bg-slate-500', newVisibilityState);
    toggleRebarBtn.classList.toggle('hover:bg-slate-600', newVisibilityState);
    toggleRebarBtn.classList.toggle('bg-indigo-500', !newVisibilityState);
    toggleRebarBtn.classList.toggle('hover:bg-indigo-600', !newVisibilityState);
}

/**
 * Lógica para alternar a visibilidade da malha.
 */
export function handleMeshToggle() {
    const allMeshSvgs = document.querySelectorAll('.diagonal-mesh-svg');
    if (allMeshSvgs.length === 0) return;
    const isCurrentlyVisible = !allMeshSvgs[0].classList.contains('hidden');
    allMeshSvgs.forEach(svg => svg.classList.toggle('hidden', isCurrentlyVisible));
    const newVisibilityState = !isCurrentlyVisible;
    toggleMeshBtn.textContent = newVisibilityState ? 'Ocultar Malha' : 'Mostrar Malha';
    toggleMeshBtn.classList.toggle('bg-slate-500', newVisibilityState);
    toggleMeshBtn.classList.toggle('hover:bg-slate-600', newVisibilityState);
    toggleMeshBtn.classList.toggle('bg-teal-500', !newVisibilityState);
    toggleMeshBtn.classList.toggle('hover:bg-teal-600', !newVisibilityState);
}

/**
 * Lógica para alternar entre a vista 2D e 3D.
 * @param {boolean} is3D - O novo estado (true para 3D, false para 2D).
 */
export function update3DViewToggle(is3D) {
    preview2DContainer.classList.toggle('hidden', is3D);
    preview3DContainer.classList.toggle('hidden', !is3D);
    if (is3D) {
        toggle3DBtn.textContent = 'Ver em 2D';
        previewTitle.textContent = 'Preview 3D Interativo';
    } else {
        toggle3DBtn.textContent = 'Ver em 3D';
        previewTitle.textContent = 'Preview da Planta (Vista Superior)';
    }
}