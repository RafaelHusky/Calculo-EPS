// =================================================================================
// IMPORTS - Importa todas as funções e elementos necessários
// =================================================================================
// Caminhos relativos funcionam, pois todos os arquivos JS estão na mesma pasta
import {
    uploadButton, fileInput, calculateBtn, modeToggle,
    epsEspessuraInput, rebocoEspessuraInput, toggleRebarBtn, toggleMeshBtn,
    toggle3DBtn, // <-- CORREÇÃO: Limpeza da importação duplicada
    displayResults, drawWallElevations, drawThicknessPreview,
    initializeTheme, handleModeToggle, handleRebarToggle, handleMeshToggle,
    update3DViewToggle, uploadStatus // Adicionado uploadStatus
} from './ui.js';

import { performCalculation } from './calculations.js';
import { drawPlanPreview } from './renderer2D.js';
import {
    initThree, onWindowResize,
    drawComplete3DStructure, update3DSkyColor
} from './renderer3D.js';

// =================================================================================
// ESTADO DA APLICAÇÃO - Variáveis que controlam o estado
// =================================================================================

let planData = null;      // Armazena o JSON da planta baixa
let is3DView = false;     // Controla se a vista 2D ou 3D está ativa
let currentCalculation = null; // Armazena os últimos resultados do cálculo

// =================================================================================
// EVENT LISTENERS - "Ouvintes" de ações do utilizador
// =================================================================================

/**
 * Lida com o carregamento de um novo ficheiro JSON (Upload Manual).
 */
function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) {
        planData = null;
        toggle3DBtn.disabled = true;
        return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const data = JSON.parse(e.target.result);
            loadPlanData(data, `Arquivo "${file.name}" carregado.`);
        } catch (error) {
            planData = null;
            toggle3DBtn.disabled = true;
            if (uploadStatus) uploadStatus.textContent = "Erro ao ler o arquivo JSON.";
            console.error(error);
        }
    };
    reader.readAsText(file);
}

/**
 * NOVA FUNÇÃO: Processa os dados da planta, seja do upload ou do localStorage.
 */
function loadPlanData(data, statusMessage) {
    planData = data;
    if (uploadStatus) uploadStatus.textContent = statusMessage;
    
    // Esconde o botão de upload, pois já temos os dados
    if (uploadButton) uploadButton.classList.add('hidden'); 
    
    drawPlanPreview(planData); // Desenha o 2D
    toggle3DBtn.disabled = false;
    
    // Se a vista 3D já estiver ativa, atualiza-a
    if (is3DView) {
        handleCalculation(); 
    }
}


/**
 * Lida com o clique no botão "Calcular e Orçar".
 */
function handleCalculation() {
    if (!planData) {
        alert("Por favor, carregue um arquivo de planta baixa primeiro.");
        return;
    }

    // 1. Reúne todos os inputs
    const inputs = {
        alturaParede: parseFloat(document.getElementById('alturaParede').value),
        epsLargura: parseFloat(document.getElementById('epsLargura').value),
        epsAltura: parseFloat(document.getElementById('epsAltura').value),
        rebocoEspessuraCm: parseFloat(rebocoEspessuraInput.value),
        vergalhoesVaoCm: parseFloat(document.getElementById('vergalhoesVao').value),
        precoPainelEPS: parseFloat(document.getElementById('precoPainelEPS').value),
        precoCimento: parseFloat(document.getElementById('precoCimento').value),
        precoAreia: parseFloat(document.getElementById('precoAreia').value),
        precoBrita: parseFloat(document.getElementById('precoBrita').value),
        precoMalha: parseFloat(document.getElementById('precoMalha').value),
        precoAditivo: parseFloat(document.getElementById('precoAditivo').value)
    };

    // 2. Chama o módulo de cálculo
    currentCalculation = performCalculation(planData, inputs);
    
    // 3. Usa os resultados para atualizar a UI
    displayResults(currentCalculation);
    drawWallElevations(
        currentCalculation.allWalls,
        currentCalculation.alturaParede,
        currentCalculation.pixelToMeter,
        currentCalculation.epsLargura,
        currentCalculation.epsAltura,
        currentCalculation.vergalhoesVaoCm
    );
    
    // 4. Se a vista 3D estiver ativa, atualiza a estrutura 3D
    if (is3DView) {
        drawComplete3DStructure(
            planData,
            currentCalculation.pixelToMeter,
            currentCalculation.alturaParede
        );
    }
}

/**
 * Lida com a alternância entre 2D e 3D.
 */
function handle3DToggle() {
    is3DView = !is3DView;
    update3DViewToggle(is3DView);

    if (is3DView) {
        initThree(); // Inicializa a cena 3D (só acontece uma vez)
        
        // Atraso para garantir que o container 3D está visível antes de redimensionar
        setTimeout(() => {
            onWindowResize();
            // Se já tivermos um cálculo, desenha a estrutura 3D
            if (currentCalculation) {
                drawComplete3DStructure(
                    planData,
                    currentCalculation.pixelToMeter,
                    currentCalculation.alturaParede
                );
            } else if (planData) {
                 // Se não tiver cálculo, mas tiver planta, calcula e desenha
                 handleCalculation();
            }
        }, 10);
    }
}

/**
 * Lida com a alternância do modo escuro.
 */
function handleThemeUpdate() {
    const isDarkMode = handleModeToggle();
    update3DSkyColor(isDarkMode); // Atualiza o céu 3D
    
    // Redesenha os previews 2D e 3D para atualizar as cores
    if (planData) {
        drawPlanPreview(planData);
        if (is3DView && currentCalculation) {
             drawComplete3DStructure(
                planData,
                currentCalculation.pixelToMeter,
                currentCalculation.alturaParede
            );
        }
    }
}

// =================================================================================
// NOVA FUNÇÃO: Carrega dados do projeto vindos do Dashboard
// =================================================================================
function loadProjectFromStorage() {
    try {
        const projectDataString = localStorage.getItem('budgeterPlanData');
        if (projectDataString) {
            // Limpa o item do storage para não carregar de novo por acidente
            localStorage.removeItem('budgeterPlanData'); 
            
            const projectData = JSON.parse(projectDataString);
            
            // Assumindo que os dados da planta estão em 'projectData'
            // ou numa propriedade como 'blueprintJson'
            const plan = projectData.blueprintJson || projectData; 
            
            if (plan && (plan.walls || plan.gridSize)) {
                console.log("Dados do projeto carregados do localStorage:", plan);
                // Atraso para garantir que a UI esteja pronta
                setTimeout(() => {
                    loadPlanData(plan, `Projeto "${projectData.name || 'do Painel'}" carregado.`);
                }, 100);
            } else {
                 if (uploadStatus) uploadStatus.textContent = "Projeto do painel não contém dados de planta válidos.";
            }
        } else {
             if (uploadStatus) uploadStatus.textContent = "Nenhum projeto carregado. Use o botão acima.";
        }
    } catch (error) {
        console.error("Erro ao carregar dados do localStorage:", error);
        if (uploadStatus) uploadStatus.textContent = "Erro ao ler dados do projeto.";
    }
}


// =================================================================================
// INICIALIZAÇÃO - Adiciona os "ouvintes" e prepara a app
// =================================================================================

function initializeApp() {
    // Ações de botões
    uploadButton.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleFileUpload);
    calculateBtn.addEventListener('click', handleCalculation);
    
    // Toggles de UI
    modeToggle.addEventListener('click', handleThemeUpdate);
    toggle3DBtn.addEventListener('click', handle3DToggle);
    toggleRebarBtn.addEventListener('click', handleRebarToggle);
    toggleMeshBtn.addEventListener('click', handleMeshToggle);
    
    // Atualização em tempo real (inputs)
    epsEspessuraInput.addEventListener('input', drawThicknessPreview);
    rebocoEspessuraInput.addEventListener('input', drawThicknessPreview);
    
    // Janela
    window.addEventListener('resize', () => {
        if (planData) drawPlanPreview(planData);
        if (is3DView) onWindowResize();
    });

    // Configuração inicial
    initializeTheme();
    drawThicknessPreview();

    // **NOVO**: Verifica se um projeto foi passado pelo dashboard
    loadProjectFromStorage();
}

// Inicia a aplicação!
initializeApp();