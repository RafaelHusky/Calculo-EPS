/**
 * Realiza todos os cálculos de quantitativos e custos.
 * @param {object} planData - O objeto JSON da planta baixa carregado.
 * @param {object} inputs - Um objeto contendo todos os valores dos campos de input.
 * @returns {object} - Um objeto com todos os resultados (quantitativos, custos, allWalls, etc.)
 */
export function performCalculation(planData, inputs) {
    const {
        alturaParede, epsLargura, epsAltura, rebocoEspessuraCm, vergalhoesVaoCm,
        precoPainelEPS, precoCimento, precoAreia, precoBrita, precoMalha, precoAditivo
    } = inputs;

    // 1. Objeto de Preços
    const precos = {
        painelEPS: precoPainelEPS,
        cimento: precoCimento,
        areia: precoAreia,
        brita: precoBrita,
        malha: precoMalha,
        aditivo: precoAditivo
    };

    // 2. Processamento das Paredes
    const gridSize = planData.gridSize || 20;
    const pixelToMeter = 0.1 / gridSize;
    let totalWallLength = 0, totalDoorArea = 0, totalWindowArea = 0;

    const allWalls = (planData.walls || []).map((wall, index) => {
        const isHorizontal = wall.orientation === 'horizontal';
        const wallLength = (isHorizontal ? wall.width : wall.height) * pixelToMeter;
        totalWallLength += wallLength;

        const wallWithObjects = {
            name: wall.name || `Parede ${index + 1}`,
            length: wallLength,
            orientation: wall.orientation, // <-- CORREÇÃO: ADICIONADO
            objects: (wall.objects || []).map(o => {
                const objLength = (o.orientation === 'horizontal' ? o.width : o.height) * pixelToMeter;
                
                // Acumula áreas de desconto
                if (o.type === 'door') totalDoorArea += objLength * 2.1;
                if (o.type === 'window') totalWindowArea += objLength * 1.2;

                return {
                    ...o,
                    pos: o.left, // Usado por drawWallElevations para objetos horizontais
                    top: o.top,  // Usado por drawWallElevations para objetos verticais
                    objLength   // Comprimento em metros
                };
            })
        };
        return wallWithObjects;
    });

    // 3. Cálculos de Área e Volume
    const wallArea = totalWallLength * alturaParede;
    const netWallArea = wallArea - totalDoorArea - totalWindowArea;
    const panelArea = epsLargura * epsAltura;

    // 4. Quantitativos
    const quantitativos = {
        epsPanels: panelArea > 0 ? Math.ceil(netWallArea / panelArea) : 0,
        rebocoVolume: netWallArea * (rebocoEspessuraCm / 100) * 2, // cm para m, 2 lados
        malhaArea: netWallArea * 2 // 2 lados
    };

    // Proporções da argamassa por m³
    const cimentoPorM3 = 6.9;  // sacos
    const areiaPorM3 = 0.62;   // m³
    const britaPorM3 = 0.36;   // m³
    const aditivoPorM3 = 1.38; // litros

    quantitativos.qtdCimento = quantitativos.rebocoVolume * cimentoPorM3;
    quantitativos.qtdAreia = quantitativos.rebocoVolume * areiaPorM3;
    quantitativos.qtdBrita = quantitativos.rebocoVolume * britaPorM3;
    quantitativos.qtdAditivo = quantitativos.rebocoVolume * aditivoPorM3;

    // 5. Custos
    const custos = {
        custoEps: quantitativos.epsPanels * precos.painelEPS,
        custoCimento: Math.ceil(quantitativos.qtdCimento) * precos.cimento, // Arredonda sacos para cima
        custoAreia: quantitativos.qtdAreia * precos.areia,
        custoBrita: quantitativos.qtdBrita * precos.brita,
        custoMalha: quantitativos.malhaArea * precos.malha,
        custoAditivo: quantitativos.qtdAditivo * precos.aditivo
    };
    custos.custoTotal = Object.values(custos).reduce((sum, val) => sum + val, 0);

    // 6. Retorna todos os resultados
    return {
        quantitativos,
        custos,
        precos,
        allWalls,
        totalWallLength,
        wallArea,
        netWallArea,
        pixelToMeter,
        // Passa alguns valores de input para as funções de desenho
        alturaParede,
        epsLargura,
        epsAltura,
        vergalhoesVaoCm
    };
}