// =================================================================================
// MÓDULO DE LÓGICA DE TEMA
// =================================================================================

// Lógica do Tema (Modo Claro/Escuro)
function setAppTheme(theme) {
    if (theme === 'dark') {
        document.documentElement.classList.add('dark');
        ui.themeToggleLightIcon.classList.add('hidden');
        ui.themeToggleDarkIcon.classList.remove('hidden');
        if(scene) scene.background.setHex(0x1f2937); // Cor de fundo 3D (gray-800)
    } else {
        document.documentElement.classList.remove('dark');
        ui.themeToggleDarkIcon.classList.add('hidden');
        ui.themeToggleLightIcon.classList.remove('hidden');
        if(scene) scene.background.setHex(0xe5e7eb); // Cor de fundo 3D (gray-200)
    }
    localStorage.setItem('theme', theme);
}

function initializeTheme() {
    // Evento de clique para alternar o tema
    ui.themeToggle.addEventListener('click', () => {
        const currentTheme = localStorage.getItem('theme') === 'dark' ? 'light' : 'dark';
        setAppTheme(currentTheme);
    });

    // Inicializa o tema na carga da página
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setAppTheme(savedTheme || (prefersDark ? 'dark' : 'light'));
}