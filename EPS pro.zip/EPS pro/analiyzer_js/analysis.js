// =================================================================================
// MÓDULO DE LÓGICA DE CÁLCULO (ANÁLISE COMPOSTA)
// =================================================================================

/**
 * Executa a análise de flambagem da parede selecionada.
 * Pega os dados dos inputs, calcula a resistência e a compara com a carga aplicada.
 */
function performBucklingAnalysis() {
    if (!selectedWallData) {
        alert("Por favor, selecione uma parede para analisar.");
        return;
    }

    // --- 1. Obter todos os parâmetros de entrada ---
    const fck = parseFloat(ui.inputs.fck.value);
    const fyk = parseFloat(ui.inputs.fyk.value);
    const mortarThickness_cm = parseFloat(ui.inputs.mortarThickness.value);
    const spacing_cm = parseFloat(ui.inputs.meshSpacing.value);
    const rebarDiameter_mm = parseFloat(ui.inputs.rebarDiameter.value);
    const rebarQuantity = parseFloat(ui.inputs.rebarQuantity.value);
    const cargaPerm = parseFloat(ui.inputs.cargaPermanente.value);
    const cargaAcid = parseFloat(ui.inputs.cargaAcidental.value);

    if (isNaN(fck) || isNaN(fyk) || isNaN(mortarThickness_cm) || isNaN(spacing_cm) || isNaN(rebarDiameter_mm) || isNaN(rebarQuantity) || isNaN(cargaPerm) || isNaN(cargaAcid)) {
        alert("Por favor, preencha todos os campos com valores numéricos válidos.");
        return;
    }

    // Verifica quais camadas estão ativas para o cálculo
    const activeLayers = {
        mortar_back: ui.toggles.mortarBack.checked,
        mesh_back: ui.toggles.meshBack.checked,
        rebars: ui.toggles.rebars.checked,
        eps: ui.toggles.eps.checked,
        mesh_front: ui.toggles.meshFront.checked,
        mortar_front: ui.toggles.mortarFront.checked
    };

    // --- 2. Definir constantes e parâmetros de cálculo (em metros, MPa, etc.) ---
    const wallHeight = 2.8; // m
    const meshWireDiameter = 0.0042; // m (malha de 4.2mm)
    const epsThickness = 0.10; // m (10cm)
    const mortarThickness = mortarThickness_cm / 100; // m

    // Módulos de elasticidade (em MPa)
    const E_concrete = 5600 * Math.sqrt(fck); // E_c conforme NBR 6118
    const E_steel = 200000; // E_s do aço
    const E_eps = 50; // E_eps (valor estimado, deve ser verificado)

    // Coeficientes de ponderação
    const gamma_c = 1.4;
    const gamma_s = 1.15;
    
    // Resistências de cálculo (em MPa)
    const f_cd = (0.85 * fck) / gamma_c;
    const f_yd = fyk / gamma_s;

    // Áreas de aço (em m² por metro linear de parede)
    const spacing_m = spacing_cm / 100; // m
    const meshWireArea = Math.PI * Math.pow(meshWireDiameter / 2, 2);
    const meshAreaPerMeter = (1 / spacing_m) * meshWireArea; // Área da malha por metro
    
    const rebarDiameter_m = rebarDiameter_mm / 1000; // m
    const rebarArea = Math.PI * Math.pow(rebarDiameter_m / 2, 2);
    const totalRebarArea = rebarQuantity * rebarArea; // Área total dos vergalhões por metro

    // --- 3. Montar a seção transversal para cálculo ---
    // (Cálculo por seção transformada, homogeneizada em concreto)
    
    const sectionLayers = [];
    let totalActiveThickness = 0; // Espessura total apenas das camadas ativas
    
    if (activeLayers.mortar_back) totalActiveThickness += mortarThickness;
    if (activeLayers.eps) totalActiveThickness += epsThickness;
    if (activeLayers.mortar_front) totalActiveThickness += mortarThickness;

    let current_pos = -totalActiveThickness / 2; // Começa da borda traseira

    // Adiciona camadas ativas à lista para cálculo
    if (activeLayers.mortar_back) {
        sectionLayers.push({ type: 'mortar', E: E_concrete, A: mortarThickness * 1, h: mortarThickness, pos_center: current_pos + mortarThickness / 2, strength: f_cd });
        current_pos += mortarThickness;
    }
    if (activeLayers.mesh_back) {
        // Posição da malha traseira (dentro da argamassa traseira, se existir)
        const pos_mesh_back = -totalActiveThickness/2 + (activeLayers.mortar_back ? (mortarThickness * 3 / 4) : 0);
        sectionLayers.push({ type: 'mesh', E: E_steel, A: meshAreaPerMeter, h: 0, pos_center: pos_mesh_back, strength: f_yd });
    }
    if (activeLayers.eps) {
        sectionLayers.push({ type: 'eps', E: E_eps, A: epsThickness * 1, h: epsThickness, pos_center: current_pos + epsThickness / 2, strength: 0 });
        current_pos += epsThickness;
    }
    if (activeLayers.mesh_front) {
        // Posição da malha frontal
        const pos_mesh_front = totalActiveThickness/2 - (activeLayers.mortar_front ? (mortarThickness * 3 / 4) : 0);
        sectionLayers.push({ type: 'mesh', E: E_steel, A: meshAreaPerMeter, h: 0, pos_center: pos_mesh_front, strength: f_yd });
    }
    if (activeLayers.mortar_front) {
        sectionLayers.push({ type: 'mortar', E: E_concrete, A: mortarThickness * 1, h: mortarThickness, pos_center: current_pos + mortarThickness / 2, strength: f_cd });
    }
     if (activeLayers.rebars && totalRebarArea > 0) {
        // Posição dos vergalhões (dentro da argamassa)
        const rebar_pos_back = -totalActiveThickness/2 + (activeLayers.mortar_back ? (mortarThickness / 4) : 0);
        const rebar_pos_front = totalActiveThickness/2 - (activeLayers.mortar_front ? (mortarThickness / 4) : 0);
        sectionLayers.push({ type: 'rebar', E: E_steel, A: totalRebarArea / 2, h: rebarDiameter_m, pos_center: rebar_pos_back, strength: f_yd });
        sectionLayers.push({ type: 'rebar', E: E_steel, A: totalRebarArea / 2, h: rebarDiameter_m, pos_center: rebar_pos_front, strength: f_yd });
    }
    
    if (sectionLayers.length === 0) {
        alert("Nenhuma camada da parede foi selecionada para o cálculo!");
        return;
    }

    // --- 4. Calcular Propriedades da Seção Transformada ---
    let sum_EA_y = 0; // Somatório (E_i * A_i * y_i)
    let sum_EA = 0;   // Somatório (E_i * A_i)
    
    sectionLayers.forEach(layer => {
        const n = layer.E / E_concrete; // Fator de homogeneização
        sum_EA_y += n * layer.A * layer.pos_center;
        sum_EA += n * layer.A;
    });

    // Posição da Linha Neutra (centroide da seção transformada)
    const neutral_axis_y = sum_EA > 0 ? sum_EA_y / sum_EA : 0;
    
    // Inércia da seção transformada (Teorema dos Eixos Paralelos)
    let I_transformed = 0;
    sectionLayers.forEach(layer => {
        const n = layer.E / E_concrete;
        const d = layer.pos_center - neutral_axis_y; // Distância do centroide da camada até a LN
        const I_layer_centroid = (1.0 * Math.pow(layer.h, 3)) / 12; // Inércia da camada (largura 1m)
        I_transformed += n * (I_layer_centroid + layer.A * Math.pow(d, 2));
    });
    
    const A_transformed = sum_EA / E_concrete; // Área transformada total
    
    // --- 5. Calcular Esbeltez e Fator de Redução (Flambagem) ---
    // Raio de giração (i = sqrt(I/A))
    const radiusOfGyration = A_transformed > 0 ? Math.sqrt(I_transformed / A_transformed) : 0;
    
    // Índice de esbeltez (λ = L_e / i) - Assumindo L_e = L (parede bi-apoiada)
    const slenderness = radiusOfGyration > 0 ? wallHeight / radiusOfGyration : Infinity;
    
    // Fator de redução de flambagem (simplificado)
    let reduction_factor = 1.0;
    if (slenderness > 200) { 
        reduction_factor = 0.1; // Limite máximo
    } else if (slenderness > 40) { 
        // Interpolação linear (exemplo simplificado)
        reduction_factor = 1.0 - 0.9 * ((slenderness - 40) / 160); 
    }
    // NOTA: Este cálculo de flambagem é uma simplificação. 
    // Uma análise correta (ex: Método da Coluna Padrão) seria mais complexa.

    // --- 6. Calcular Cargas (Aplicada vs. Resistente) ---
    
    // Carga Resistente de Cálculo (N_rd)
    // Resistência do material (sem flambagem)
    let N_rd_material = 0; 
    sectionLayers.forEach(layer => { 
        N_rd_material += layer.A * layer.strength; // (Área * f_d)
    });
    
    // Resistência final, reduzida pela flambagem (em kN/m)
    const N_rd = (reduction_factor * N_rd_material) * 1000; 

    // Carga Aplicada de Cálculo (N_sd) (em kN/m)
    const gamma_f = 1.4; // Coeficiente de majoração de carga
    const N_sd = (cargaPerm + cargaAcid) * gamma_f;
    
    // --- 7. Apresentar Resultados ---
    const utilization = N_rd > 0 ? (N_sd / N_rd) : Infinity;
    const isApproved = utilization < 1.0;

    ui.analysisStatus.textContent = isApproved ? "APROVADO" : "REPROVADO";
    ui.analysisStatus.className = isApproved ? "text-xl font-bold mb-3 text-center approved" : "text-xl font-bold mb-3 text-center reproved";
    ui.analysisResults.className = isApproved ? "absolute top-4 right-4 w-80 max-w-full backdrop-blur-sm rounded-lg shadow-xl border z-10 approved" : "absolute top-4 right-4 w-80 max-w-full backdrop-blur-sm rounded-lg shadow-xl border z-10 reproved";
    
    ui.appliedLoad.textContent = `${N_sd.toFixed(2)} kN/m`;
    ui.resistantLoad.textContent = `${N_rd.toFixed(2)} kN/m`;
    ui.utilizationRate.textContent = `${(utilization * 100).toFixed(1)}%`;

    // Preenche os detalhes do cálculo no relatório
    ui.reports.wallHeight.textContent = `${wallHeight.toFixed(2)} m`;
    ui.reports.totalThickness.textContent = `${(totalActiveThickness * 100).toFixed(1)} cm`;
    ui.reports.radiusGyration.textContent = `${(radiusOfGyration * 100).toFixed(2)} cm`;
    ui.reports.slenderness.textContent = `${slenderness.toFixed(1)}`;
    ui.reports.reductionFactor.textContent = `${reduction_factor.toFixed(3)}`;
    
    const EA_eq_kNm = sum_EA * 1000; // Rigidez Axial (em kN/m)
    ui.reports.axialStiffness.textContent = `${EA_eq_kNm.toFixed(0)} kN/m`;
    
    const I_transformed_cm4 = I_transformed * Math.pow(100, 4); // Inércia (em cm⁴/m)
    ui.reports.sectionInertia.textContent = `${I_transformed_cm4.toFixed(0)} cm⁴/m`;
    ui.reports.materialStrength.textContent = `${(N_rd_material * 1000).toFixed(2)} kN/m`;
    
    ui.analysisResults.classList.remove('hidden');
    
    // Atualiza a cor da parede na cena 3D
    updateWallColor(selectedWallObject, isApproved);
}