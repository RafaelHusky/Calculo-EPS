// =================================================================================
// MÓDULO DE RENDERIZAÇÃO 2D (Planta Baixa)
// =================================================================================

/**
 * Desenha a pré-visualização da planta baixa no canvas 2D.
 * @param {object} data - O objeto de dados da planta (planData).
 */
function drawPlanPreview(data) {
    const ctx = ui.planCanvas.getContext('2d');
    // Ajusta o tamanho do canvas ao seu elemento DOM para evitar distorção
    ui.planCanvas.width = ui.planCanvas.offsetWidth;
    ui.planCanvas.height = ui.planCanvas.offsetHeight;
    
    const allElements = data.walls || [];
    if (allElements.length === 0) return;

    // Encontra os limites (bounding box) de toda a planta
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    allElements.forEach(el => {
        minX = Math.min(minX, el.left); 
        minY = Math.min(minY, el.top);
        maxX = Math.max(maxX, el.left + el.width); 
        maxY = Math.max(maxY, el.top + el.height);
    });

    const drawingWidth = maxX - minX; 
    const drawingHeight = maxY - minY;
    
    // Calcula a escala para caber no canvas com um padding
    const padding = 10;
    const scale = Math.min(
        (ui.planCanvas.width - padding * 2) / drawingWidth, 
        (ui.planCanvas.height - padding * 2) / drawingHeight
    );

    // Calcula o offset para centralizar o desenho
    const offsetX = (ui.planCanvas.width - drawingWidth * scale) / 2 - minX * scale;
    const offsetY = (ui.planCanvas.height - drawingHeight * scale) / 2 - minY * scale;

    ctx.clearRect(0, 0, ui.planCanvas.width, ui.planCanvas.height);
    ctx.save();
    
    // Aplica a transformação de centralização e escala
    ctx.translate(offsetX, offsetY); 
    ctx.scale(scale, scale);

    // Desenha as paredes
    (data.walls || []).forEach(wall => {
        ctx.fillStyle = '#4b5563'; // Cor da parede
        ctx.fillRect(wall.left, wall.top, wall.width, wall.height);
        
        // Desenha objetos (portas/janelas) dentro da parede
        (wall.objects || []).forEach(obj => {
            ctx.fillStyle = obj.type === 'door' ? '#f59e0b' : '#38bdf8'; // Laranja para porta, azul para janela
            ctx.fillRect(wall.left + obj.left, wall.top + obj.top, obj.width, obj.height);
        });
    });
    
    ctx.restore();
}