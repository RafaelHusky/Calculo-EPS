// =================================================================================
// MÓDULO PRINCIPAL (MAIN) - LÓGICA DE EVENTOS E UI
// =================================================================================

/**
 * Ponto de entrada principal da aplicação.
 * É chamado assim que o DOM está pronto.
 */
document.addEventListener('DOMContentLoaded', () => {
    
    // Inicializa o tema (claro/escuro)
    initializeTheme(); 

    // --- Event Listeners Principais ---
    
    ui.uploadButton.addEventListener('click', () => ui.fileInput.click());
    ui.viewCompleteStructureButton.addEventListener('click', generateCompleteStructure);
    ui.analyzeButton.addEventListener('click', performBucklingAnalysis);
    ui.closeReportButton.addEventListener('click', () => ui.analysisResults.classList.add('hidden'));

    // Evento de seleção de arquivo
    ui.fileInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                planData = JSON.parse(e.target.result);
                alert("Planta carregada com sucesso!");
                
                // Popula a UI com os dados carregados
                populateWallList(planData.walls);
                drawPlanPreview(planData);
                
                ui.viewCompleteStructureButton.classList.remove('hidden');
            } catch (error) {
                alert("Erro ao carregar o arquivo JSON.");
                console.error(error);
                ui.viewCompleteStructureButton.classList.add('hidden');
            }
        };
        reader.readAsText(file);
    });

    // ===============================================================
    // == CORREÇÃO APLICADA ==
    // Adiciona um listener de resize para redesenhar o canvas 2D
    // (O 3D já tem o seu próprio listener no render3D.js)
    // ===============================================================
    window.addEventListener('resize', () => {
        if (planData) {
            // Atraso leve (debounce) para garantir que o DOM tenha o tamanho final
            setTimeout(() => {
                drawPlanPreview(planData);
            }, 100);
        }
    });
    
    // --- Event Listeners para Controles da Sidebar ---

    /**
     * Função única chamada quando qualquer controle (toggle ou input)
     * na sidebar é alterado.
     */
    function handleControlChange() {
        // Se uma parede estiver selecionada, ela é re-gerada com os novos parâmetros
        if (selectedWallData) {
            generate3DWall(selectedWallData, true); 
        } else if (structureGroup && structureGroup.children.length > 0) {
            // Se a estrutura completa estiver visível, re-gera ela
            generateCompleteStructure();
        }
        
        // Esconde resultados de análise antigos, pois os parâmetros mudaram
        ui.analysisResults.classList.add('hidden');
        resetAllWallColors(); // Reseta cores de aprovação/reprovação
    }

    // Adiciona o listener para todos os toggles
    Object.values(ui.toggles).forEach(toggle => toggle.addEventListener('change', handleControlChange));
    
    // Adiciona o listener para os inputs de geometria/material
    ui.inputs.mortarThickness.addEventListener('input', handleControlChange);
    ui.inputs.meshSpacing.addEventListener('input', handleControlChange);
    ui.inputs.rebarDiameter.addEventListener('input', handleControlChange);
    ui.inputs.rebarQuantity.addEventListener('input', handleControlChange);
    
    // Listeners de FCK/FYK (não precisam redesenhar a 3D, apenas limpar análise)
    ui.inputs.fck.addEventListener('input', () => ui.analysisResults.classList.add('hidden'));
    ui.inputs.fyk.addEventListener('input', () => ui.analysisResults.classList.add('hidden'));
});


// =================================================================================
// MÓDULO DE INTERAÇÃO E UI (Funções Auxiliares)
// =================================================================================

/**
 * Cria a lista de paredes clicáveis na sidebar
 * @param {Array} walls - Array de dados das paredes.
 */
function populateWallList(walls) {
    ui.wallList.innerHTML = ''; // Limpa a lista antiga
    
    if (!walls || walls.length === 0) {
        ui.wallList.innerHTML = `<p class="text-main-placeholder text-sm">Nenhuma parede encontrada.</p>`;
        return;
    }
    
    walls.forEach((wall, index) => {
        const wallItem = document.createElement('div');
        wallItem.className = 'wall-item p-2 rounded-md border border-transparent text-main-content cursor-pointer';
        wallItem.textContent = wall.name || `Parede ${index + 1}`;
        wallItem.dataset.wallId = wall.id;
        
        // Evento de clique para selecionar uma parede
        wallItem.addEventListener('click', () => {
            resetAllWallColors();
            selectedWallData = wall;
            
            // Destaca o item selecionado na lista
            document.querySelectorAll('.wall-item').forEach(item => item.classList.remove('active'));
            wallItem.classList.add('active');
            
            // Mostra os painéis de análise e esconde resultados antigos
            ui.propertiesPanel.classList.remove('hidden');
            ui.viewControlsPanel.classList.remove('hidden');
            ui.analysisResults.classList.add('hidden');
            ui.wallTitle.textContent = `Carregamentos na ${wall.name || `Parede ${index + 1}`}`;
            
            // Gera a visualização 3D da parede selecionada
            generate3DWall(wall, true);
        });
        ui.wallList.appendChild(wallItem);
    });
}

/**
 * Atualiza a visibilidade das camadas na cena 3D com base nos checkboxes.
 * @param {THREE.Group} wallGroup - O grupo 3D da parede.
 */
function updateLayerVisibility(wallGroup) {
    if (!wallGroup) return;
    wallGroup.children.forEach(layer => {
        // Encontra o toggle correspondente ao nome da camada (ex: 'eps', 'mortarFront')
        const toggle = ui.toggles[layer.name];
        if(toggle) { 
            layer.visible = toggle.checked; 
        }
    });
}

/**
 * Muda a cor da parede 3D com base no resultado da análise.
 * @param {THREE.Object3D} wallObject - O objeto 3D da parede.
 * @param {boolean} isApproved - true se APROVADO, false se REPROVADO.
 */
function updateWallColor(wallObject, isApproved) {
    if (!wallObject) return;
    
    const color = isApproved ? 0x4ade80 : 0xf87171; // Verde / Vermelho
    
    wallObject.traverse(child => {
        // Aplica a cor apenas às camadas de argamassa
        if (child.isMesh && child.material && child.name.startsWith('mortar')) {
            // Salva a cor original antes de mudar
            if (!originalWallColors[child.uuid]) {
                originalWallColors[child.uuid] = child.material.color.getHex();
            }
            child.material.color.setHex(color);
        }
    });
}

/**
 * Restaura a cor original de todas as paredes na cena 3D.
 */
function resetAllWallColors() {
     if (!structureGroup) return;
     
     structureGroup.traverse(object => {
         if (object.isMesh && object.material && originalWallColors[object.uuid]) {
             // Restaura a cor original que foi salva
             object.material.color.setHex(originalWallColors[object.uuid]);
         }
     });
}