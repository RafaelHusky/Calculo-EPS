// =================================================================================
// MÓDULO DE INICIALIZAÇÃO E SETUP
// =================================================================================

const ui = {
    uploadButton: document.getElementById('upload-button'),
    viewCompleteStructureButton: document.getElementById('view-complete-structure-button'),
    fileInput: document.getElementById('file-input'),
    planCanvas: document.getElementById('plan-preview-canvas'),
    wallList: document.getElementById('wall-list'),
    threeCanvas: document.getElementById('three-canvas'),
    placeholderText: document.getElementById('placeholder-text'),
    propertiesPanel: document.getElementById('properties-panel'),
    viewControlsPanel: document.getElementById('view-controls-panel'),
    wallTitle: document.getElementById('wall-title'),
    analyzeButton: document.getElementById('analyze-button'),
    analysisResults: document.getElementById('analysis-results'),
    closeReportButton: document.getElementById('close-report-button'),
    analysisStatus: document.getElementById('analysis-status'),
    appliedLoad: document.getElementById('applied-load'),
    resistantLoad: document.getElementById('resistant-load'),
    utilizationRate: document.getElementById('utilization-rate'),
    // Referências do tema RE-ADICIONADAS
    themeToggle: document.getElementById('theme-toggle'),
    themeToggleDarkIcon: document.getElementById('theme-toggle-dark-icon'),
    themeToggleLightIcon: document.getElementById('theme-toggle-light-icon'),
    toggles: {
        mortarFront: document.getElementById('toggle-mortar-front'),
        meshFront: document.getElementById('toggle-mesh-front'),
        rebars: document.getElementById('toggle-rebars'),
        eps: document.getElementById('toggle-eps'),
        meshBack: document.getElementById('toggle-mesh-back'),
        mortarBack: document.getElementById('toggle-mortar-back'),
    },
    inputs: {
        mortarThickness: document.getElementById('mortar-thickness'),
        meshSpacing: document.getElementById('mesh-spacing'),
        rebarDiameter: document.getElementById('rebar-diameter'),
        rebarQuantity: document.getElementById('rebar-quantity'),
        fck: document.getElementById('fck'),
        fyk: document.getElementById('fyk'),
        cargaPermanente: document.getElementById('carga-permanente'),
        cargaAcidental: document.getElementById('carga-acidental'),
    },
    reports: {
        wallHeight: document.getElementById('report-wall-height'),
        totalThickness: document.getElementById('report-total-thickness'),
        radiusGyration: document.getElementById('report-radius-gyration'),
        slenderness: document.getElementById('report-slenderness'),
        reductionFactor: document.getElementById('report-reduction-factor'),
        axialStiffness: document.getElementById('report-axial-stiffness'),
        sectionInertia: document.getElementById('report-section-inertia'),
        materialStrength: document.getElementById('report-material-strength'),
    }
};

// Variáveis globais que serão usadas pelos outros scripts
let planData = null;
let selectedWallData = null;
let selectedWallObject = null;
let originalWallColors = {};
let scene, camera, renderer, controls, structureGroup;