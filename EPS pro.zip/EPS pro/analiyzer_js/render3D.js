// =================================================================================
// MÓDULO DE RENDERIZAÇÃO 3D (Three.js)
// =================================================================================

/**
 * Inicializa a cena 3D (Scene, Camera, Renderer, Controls).
 * Só é executado uma vez.
 */
function initThree() {
    if (scene) return; // Evita re-inicialização
    
    scene = new THREE.Scene();
    
    // Define o fundo com base no tema ATUAL
    const isDark = document.documentElement.classList.contains('dark');
    scene.background = new THREE.Color(isDark ? 0x1f2937 : 0xe5e7eb); // gray-800 / gray-200
    
    camera = new THREE.PerspectiveCamera(50, ui.threeCanvas.clientWidth / ui.threeCanvas.clientHeight, 0.1, 1000);
    scene.add(camera);

    // Iluminação
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(10, 20, 5);
    camera.add(directionalLight); // Luz acompanha a câmera

    // Renderer
    renderer = new THREE.WebGLRenderer({ canvas: ui.threeCanvas, antialias: true });
    // O tamanho é definido com o canvas (que pode estar 0x0)
    renderer.setSize(ui.threeCanvas.clientWidth, ui.threeCanvas.clientHeight); 
    renderer.setPixelRatio(window.devicePixelRatio);

    // Controles
    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;

    // Grupo principal para todos os objetos da estrutura
    structureGroup = new THREE.Group();
    scene.add(structureGroup);

    // Loop de animação
    function animate() {
        requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
    }
    animate();
    
    // Lidar com redimensionamento da janela
    window.addEventListener('resize', onWindowResize);
}

/**
 * Ajusta o tamanho do renderer e o aspect ratio da câmera
 * quando a janela do navegador muda de tamanho.
 */
function onWindowResize() {
    // Pega o container PAI, que tem o tamanho correto do flexbox
    const container = document.getElementById('viewer-container');
    if (!container || !camera || !renderer) return; 
    
    // Se o container for minúsculo, não faz nada
    if (container.clientWidth < 10 || container.clientHeight < 10) return;
    
    camera.aspect = container.clientWidth / container.clientHeight;
    camera.updateProjectionMatrix();
    // Define o tamanho do renderer para o tamanho do container
    renderer.setSize(container.clientWidth, container.clientHeight);
}

/**
 * Cria o objeto 3D completo de uma parede, incluindo todas as suas camadas.
 * @param {object} wallData - Dados da parede (do JSON).
 * @param {number} pixelToMeter - Fator de conversão.
 * @returns {THREE.Group} - O grupo 3D contendo todas as camadas da parede.
 */
function createWall3DObject(wallData, pixelToMeter) {
    const wallHeight = 2.8; // Altura padrão da parede (em metros)
    const epsThickness = 0.10; // Espessura padrão do EPS (10cm)
    
    // Pega valores dos inputs
    const mortarThickness_cm = parseFloat(ui.inputs.mortarThickness.value) || 3;
    const mortarThickness = mortarThickness_cm / 100; // cm para m
    const rebarDiameter_mm = parseFloat(ui.inputs.rebarDiameter.value) || 8;
    const rebarDiameter = rebarDiameter_mm / 1000; // mm para m

    const isHorizontal = wallData.orientation === 'horizontal';
    const wallLength = (isHorizontal ? wallData.width : wallData.height) * pixelToMeter;
    const openings = wallData.objects || [];

    const wallGroup = new THREE.Group();
    wallGroup.name = wallData.id;

    // --- 1. Criar a Forma 2D da Parede com Furos ---
    const halfLength = wallLength / 2;
    const halfHeight = wallHeight / 2;
    const wallShape = new THREE.Shape();
    // Coordenadas centradas na origem (0,0)
    wallShape.moveTo(-halfLength, -halfHeight);
    wallShape.lineTo( halfLength, -halfHeight);
    wallShape.lineTo( halfLength,  halfHeight);
    wallShape.lineTo(-halfLength,  halfHeight);
    wallShape.lineTo(-halfLength, -halfHeight);
    
    // Adiciona buracos (portas/janelas)
    const holes = (openings || []).map(obj => {
        const path = new THREE.Path();
        const holeW = (isHorizontal ? obj.width : obj.height) * pixelToMeter;
        const holeH = (obj.type === 'door' ? 2.1 : 1.2); // Altura da porta/janela
        const holeX_original = (isHorizontal ? obj.left : obj.top) * pixelToMeter;
        const holeY_original = (obj.type === 'door' ? 0 : 0.9); // Posição Y da porta/janela
        
        // Converte para coordenadas centradas
        const holeX_centered = holeX_original - halfLength;
        const holeY_centered = holeY_original - halfHeight;
        
        path.moveTo(holeX_centered, holeY_centered);
        path.lineTo(holeX_centered + holeW, holeY_centered);
        path.lineTo(holeX_centered + holeW, holeY_centered + holeH);
        path.lineTo(holeX_centered, holeY_centered + holeH);
        path.lineTo(holeX_centered, holeY_centered);
        return path;
    });
    wallShape.holes = holes;
    
    // --- 2. Camada de EPS (Núcleo) ---
    const epsGeom = new THREE.ExtrudeGeometry(wallShape, { depth: epsThickness, bevelEnabled: false });
    const epsMat = new THREE.MeshStandardMaterial({ color: 0x87ceeb, transparent: true, opacity: 0.8 });
    const epsLayer = new THREE.Mesh(epsGeom, epsMat);
    epsLayer.name = 'eps';
    epsLayer.position.z = -epsThickness / 2; // Centraliza o EPS no eixo Z
    wallGroup.add(epsLayer);
    
    // --- 3. Camadas de Argamassa ---
    const mortarGeom = new THREE.ExtrudeGeometry(wallShape, { depth: mortarThickness, bevelEnabled: false });
    const mortarMat = new THREE.MeshStandardMaterial({ color: 0xcccccc, side: THREE.DoubleSide, transparent: true, opacity: 0.9 });
    
    const mortarFrontLayer = new THREE.Mesh(mortarGeom, mortarMat.clone());
    mortarFrontLayer.name = 'mortarFront';
    mortarFrontLayer.position.z = epsThickness / 2; // Lado frontal
    wallGroup.add(mortarFrontLayer);
    
    const mortarBackLayer = new THREE.Mesh(mortarGeom, mortarMat.clone());
    mortarBackLayer.name = 'mortarBack';
    mortarBackLayer.position.z = -epsThickness / 2 - mortarThickness; // Lado traseiro
    wallGroup.add(mortarBackLayer);
    
    // --- 4. Vergalhões de Reforço ---
    const rebarGroup = new THREE.Group();
    rebarGroup.name = 'rebars';
    const rebarGeom = new THREE.CylinderGeometry(rebarDiameter / 2, rebarDiameter / 2, wallHeight, 8);
    const rebarMat = new THREE.MeshStandardMaterial({ color: 0xCD7F32 }); // Cor de bronze
    
    const rebarQuantityPerMeter = parseFloat(ui.inputs.rebarQuantity.value) || 2;
    const numRebars = Math.max(2, Math.round(rebarQuantityPerMeter * wallLength));
    const rebarSpacing = wallLength > mortarThickness*2 ? (wallLength - mortarThickness*2) / (numRebars - 1) : 0;
    
    // Buracos centralizados para verificação de colisão
    const centeredHoles = (openings || []).map(obj => ({
        x: ((isHorizontal ? obj.left : obj.top) * pixelToMeter) - halfLength,
        w: (isHorizontal ? obj.width : obj.height) * pixelToMeter
    }));

    for (let i = 0; i < numRebars; i++) {
        const xPos = -halfLength + mortarThickness + i * rebarSpacing;
        
        // Verifica se o vergalhão cai dentro de um buraco
        const isInHole = centeredHoles.some(hole => xPos >= hole.x && xPos <= hole.x + hole.w);

        if (!isInHole) {
            // Posição Z dos vergalhões (dentro da argamassa)
            const rebarZ_front = epsThickness / 2 + (mortarThickness / 4);
            const rebarZ_back = -epsThickness / 2 - (mortarThickness / 4);

            const rebarFront = new THREE.Mesh(rebarGeom, rebarMat);
            rebarFront.position.set(xPos, 0, rebarZ_front);
            rebarGroup.add(rebarFront);
            
            const rebarBack = new THREE.Mesh(rebarGeom, rebarMat);
            rebarBack.position.set(xPos, 0, rebarZ_back);
            rebarGroup.add(rebarBack);
        }
    }
    wallGroup.add(rebarGroup);

    // --- 5. Malhas de Superfície ---
    const meshFrontGroup = generateMeshWithHoles(wallData, wallLength, wallHeight, openings, pixelToMeter);
    meshFrontGroup.name = 'meshFront';
    const meshBackGroup = meshFrontGroup.clone();
    meshBackGroup.name = 'meshBack';
    
    // Posição Z das malhas (dentro da argamassa, mais externas que os vergalhões)
    meshFrontGroup.position.z = epsThickness / 2 + (mortarThickness * 3 / 4); 
    meshBackGroup.position.z = -epsThickness / 2 - (mortarThickness * 3 / 4);
    wallGroup.add(meshFrontGroup);
    wallGroup.add(meshBackGroup);

    return wallGroup;
}

/**
 * Gera um grupo de linhas (malha) que respeita os buracos da parede.
 */
function generateMeshWithHoles(wallData, wallLength, wallHeight, openings, pixelToMeter) {
    const meshGroup = new THREE.Group();
    
    // A cor da malha é definida dinamicamente com base no tema
    const isDark = document.documentElement.classList.contains('dark');
    const meshColor = isDark ? 0x374151 : 0x9ca3af; // gray-700 escuro, gray-400 claro
    const meshMat = new THREE.LineBasicMaterial({ color: meshColor });
    
    const spacing = parseFloat(ui.inputs.meshSpacing.value) / 100 || 0.15; // cm para m
    const halfLength = wallLength / 2;
    const halfHeight = wallHeight / 2;
    
    const isHorizontal = wallData.orientation === 'horizontal';
    const holes = (openings || []).map(obj => ({
        x: ((isHorizontal ? obj.left : obj.top) * pixelToMeter) - halfLength,
        y: (obj.type === 'door' ? 0 : 0.9) - halfHeight,
        w: (isHorizontal ? obj.width : obj.height) * pixelToMeter,
        h: obj.type === 'door' ? 2.1 : 1.2
    }));

    // Linhas Verticais
    for (let x = -halfLength; x <= halfLength; x += spacing) {
        const intersectingHoles = holes.filter(h => x > h.x && x < h.x + h.w).sort((a, b) => a.y - b.y);
        let currentY = -halfHeight;
        intersectingHoles.forEach(hole => {
            if (currentY < hole.y) {
                const points = [new THREE.Vector3(x, currentY, 0), new THREE.Vector3(x, hole.y, 0)];
                meshGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), meshMat));
            }
            currentY = hole.y + hole.h;
        });
        if (currentY < halfHeight) {
            const points = [new THREE.Vector3(x, currentY, 0), new THREE.Vector3(x, halfHeight, 0)];
            meshGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), meshMat));
        }
    }
    
    // Linhas Horizontais
    for (let y = -halfHeight; y <= halfHeight; y += spacing) {
        const intersectingHoles = holes.filter(h => y > h.y && y < h.y + h.h).sort((a, b) => a.x - b.x);
        let currentX = -halfLength;
        intersectingHoles.forEach(hole => {
            if (currentX < hole.x) {
                const points = [new THREE.Vector3(currentX, y, 0), new THREE.Vector3(hole.x, y, 0)];
                meshGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), meshMat));
            }
            currentX = hole.x + hole.w;
        });
        if (currentX < halfLength) {
            const points = [new THREE.Vector3(currentX, y, 0), new THREE.Vector3(halfLength, y, 0)];
            meshGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points), meshMat));
        }
    }
    return meshGroup;
}

/**
 * Limpa todos os objetos da cena 3D para carregar novos.
 */
function clearScene() {
    if (!structureGroup) return;
    while(structureGroup.children.length > 0) {
        const object = structureGroup.children[0];
        structureGroup.remove(object);
        
        // Libera memória (geometria e materiais)
        if(object.traverse) {
            object.traverse(child => {
                if (child.geometry) child.geometry.dispose();
                if (child.material) {
                    if (Array.isArray(child.material)) {
                        child.material.forEach(material => material.dispose());
                    } else {
                        child.material.dispose();
                    }
                }
            });
        }
    }
    originalWallColors = {}; // Limpa o cache de cores
}
        
/**
 * Foca a câmera em um objeto 3D específico.
 * @param {THREE.Object3D} targetObject - O objeto para focar.
 */
function focusCameraOn(targetObject) {
    const box = new THREE.Box3().setFromObject(targetObject);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z);
    
    // Calcula a distância da câmera para enquadrar o objeto
    const fov = camera.fov * (Math.PI / 180);
    const cameraDist = Math.abs(maxDim / Math.tan(fov / 2)) * 1.5; // 1.5x de zoom out
    
    controls.reset();
    controls.target.copy(center);
    
    camera.position.copy(center);
    // Posiciona a câmera para uma visão 3/4
    camera.position.z += cameraDist > 0.1 ? cameraDist : 20;
    camera.position.y += (cameraDist > 0.1 ? cameraDist : 20) * 0.5;
    
    controls.update();
}

/**
 * Função principal para gerar uma única parede na cena.
 * @param {object} wallData - Dados da parede.
 * @param {boolean} shouldClear - Se deve limpar a cena antes de adicionar.
 */
function generate3DWall(wallData, shouldClear = true) {
    initThree(); // Garante que a cena 3D esteja inicializada
    
    // <-- CORREÇÃO 1 (Bug do Canvas Pequeno)
    // Força o redimensionamento logo após a inicialização
    setTimeout(onWindowResize, 10);
    
    if(shouldClear) clearScene();
    
    ui.placeholderText.classList.add('hidden');
    
    // Fator de conversão (ex: 20 pixels = 10cm = 0.1m)
    const pixelToMeter = 0.1 / (planData.gridSize || 20); 
    
    const wallObject = createWall3DObject(wallData, pixelToMeter);
    selectedWallObject = wallObject; // Armazena a referência do objeto selecionado
    
    const wallHeight = 2.8; 
    wallObject.position.y = wallHeight / 2; // Levanta a parede para ficar sobre o "chão" (Y=0)
    
    updateLayerVisibility(wallObject); // Aplica a visibilidade dos toggles
    structureGroup.add(wallObject);
    focusCameraOn(wallObject); // Foca a câmera na parede recém-criada
}

/**
 * Gera a estrutura completa da planta baixa em 3D.
 */
function generateCompleteStructure() {
    initThree();
    
    // <-- CORREÇÃO 1 (Bug do Canvas Pequeno)
    // Força o redimensionamento logo após a inicialização
    setTimeout(onWindowResize, 10);
    
    clearScene();
    
    ui.placeholderText.classList.add('hidden');
    // Desseleciona qualquer parede na UI
    document.querySelectorAll('.wall-item').forEach(item => item.classList.remove('active'));
    ui.propertiesPanel.classList.add('hidden');
    ui.viewControlsPanel.classList.add('hidden');
    ui.analysisResults.classList.add('hidden');
    selectedWallData = null;
    selectedWallObject = null;
    
    if (!planData || !planData.walls) return;
    
    const pixelToMeter = 0.1 / (planData.gridSize || 20);

    // Encontra o centro da estrutura para centralizá-la na cena 3D
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    planData.walls.forEach(wall => {
        minX = Math.min(minX, wall.left);
        minY = Math.min(minY, wall.top);
        maxX = Math.max(maxX, wall.left + wall.width);
        maxY = Math.max(maxY, wall.top + wall.height);
    });
    const structureCenterX = minX + (maxX - minX) / 2;
    const structureCenterY = minY + (maxY - minY) / 2;
    
    // Cria e posiciona cada parede
    planData.walls.forEach(wall => {
        const wallObject = createWall3DObject(wall, pixelToMeter);
        
        // Calcula a posição da parede relativa ao centro da estrutura
        const wallCenterX_pixels = wall.left + wall.width / 2;
        const wallCenterY_pixels = wall.top + wall.height / 2;
        
        // Mapeia (X, Y) da planta 2D para (X, Z) da cena 3D
        const posX = (wallCenterX_pixels - structureCenterX) * pixelToMeter;
        const posZ = (wallCenterY_pixels - structureCenterY) * pixelToMeter;
        
        const wallHeight = 2.8; 
        wallObject.position.set(posX, wallHeight / 2, posZ);
        
        if (wall.orientation === 'vertical') {
             wallObject.rotateY(Math.PI / 2); // Rotaciona paredes verticais
        }
        
        // <-- CORREÇÃO 2 (Bug da "Visão Geral")
        // Aplica os toggles de visibilidade a esta parede
        updateLayerVisibility(wallObject);
        
        structureGroup.add(wallObject);
    });
    
    focusCameraOn(structureGroup); // Foca na estrutura inteira
}