import { dom, state } from './main.js';
import { updateStandaloneWallAppearance, getScale } from './canvas.js';
import { onStandaloneWallMouseDown, onWallObjectMouseDown } from './controls.js';
import { showWallContextMenu, showSizeEditor, selectElement } from './ui.js';

export const gridSize = 20;

export function finalizeStandaloneWall(wall, options = {}) {
    wall.classList.remove('preview');
    wall.classList.add('standalone-wall');
    wall.id = options.id || `wall-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    
    wall.addEventListener('mousedown', onStandaloneWallMouseDown);
    // CORREÇÃO: Adiciona o listener para o clique-duplo que estava faltando
    wall.addEventListener('dblclick', (e) => showWallContextMenu(e, wall));

    const handleStart = document.createElement('div');
    handleStart.className = 'wall-resize-handle start';
    wall.appendChild(handleStart);

    const handleEnd = document.createElement('div');
    handleEnd.className = 'wall-resize-handle end';
    wall.appendChild(handleEnd);

    const nameSpan = document.createElement('span');
    nameSpan.className = 'element-name';
    if (options.name) {
        wall.dataset.name = options.name;
        nameSpan.textContent = options.name;
        nameSpan.style.display = 'block';
    }
    wall.appendChild(nameSpan);

    if (options.objects) {
        options.objects.forEach(objData => createWallObject(wall, objData));
    }

    updateStandaloneWallAppearance(wall);
    return wall;
}

/**
 * ADICIONADO: A função central que cria uma cópia da parede.
 * @param {HTMLElement} originalWall - A parede a ser duplicada.
 */
export function duplicateWall(originalWall) {
    if (!originalWall || !originalWall.classList.contains('standalone-wall')) return;

    const wallData = {
        name: originalWall.dataset.name,
        left: originalWall.offsetLeft + gridSize,
        top: originalWall.offsetTop + gridSize,
        width: originalWall.offsetWidth,
        height: originalWall.offsetHeight,
        orientation: originalWall.dataset.orientation,
        objects: []
    };

    originalWall.querySelectorAll('.wall-object').forEach(obj => {
        wallData.objects.push({
            type: obj.classList.contains('door') ? 'door' : 'window',
            orientation: obj.dataset.orientation,
            left: obj.offsetLeft, top: obj.offsetTop,
            width: obj.offsetWidth, height: obj.offsetHeight
        });
    });

    const newWallEl = document.createElement('div');
    newWallEl.dataset.orientation = wallData.orientation;
    Object.assign(newWallEl.style, {
        left: `${wallData.left}px`, top: `${wallData.top}px`,
        width: `${wallData.width}px`, height: `${wallData.height}px`,
    });

    dom.canvas.appendChild(newWallEl);
    const newWall = finalizeStandaloneWall(newWallEl, wallData);
    
    selectElement(newWall);
}

export function createWallObject(parentEl, options) {
    const obj = document.createElement('div');
    obj.className = `wall-object ${options.type}`;
    obj.dataset.orientation = options.orientation;
    obj.style.left = `${options.left}px`;
    obj.style.top = `${options.top}px`;
    obj.style.width = `${options.width}px`;
    obj.style.height = `${options.height}px`;

    obj.addEventListener('mousedown', onWallObjectMouseDown);
    obj.addEventListener('dblclick', showSizeEditor);
    parentEl.appendChild(obj);
    return obj;
}

export function placeWallObject(wall, e, type) {
    const scale = getScale();
    const wallRect = wall.getBoundingClientRect();
    const clickX_relativeToWall = (e.clientX - wallRect.left) / scale;
    const clickY_relativeToWall = (e.clientY - wallRect.top) / scale;
    const isVertical = wall.dataset.orientation === 'vertical';
    const defaultWidth = (type === 'door' ? 82 : 120);
    const lengthAlongWallPx = (defaultWidth / 10) * gridSize;
    const wallObjThicknessPx = 8;
    
    const options = {
        type: type,
        orientation: isVertical ? 'vertical' : 'horizontal',
        width: isVertical ? wallObjThicknessPx : lengthAlongWallPx,
        height: isVertical ? lengthAlongWallPx : wallObjThicknessPx,
    };

    if (isVertical) {
        options.left = wall.offsetWidth / 2 - wallObjThicknessPx / 2;
        options.top = clickY_relativeToWall - lengthAlongWallPx / 2;
    } else {
        options.top = wall.offsetHeight / 2 - wallObjThicknessPx / 2;
        options.left = clickX_relativeToWall - lengthAlongWallPx / 2;
    }
    createWallObject(wall, options);
}
