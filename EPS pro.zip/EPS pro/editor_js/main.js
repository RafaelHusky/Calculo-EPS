// js/main.js (VERSÃO FINAL - CARREGANDO PROJETO DO LOCALSTORAGE)
// ESTA É A VERSÃO ORIGINAL, QUE FUNCIONA COM editor.html

import { initCanvas, applyTransform, updateAllWallsAppearance } from './canvas.js';
import { initControls } from './controls.js';
import { initUI } from './ui.js';
// MUDANÇA: Importa initDataHandlers E rebuildCanvas
import { initDataHandlers, rebuildCanvas } from './data.js';

export let state = {
    activeElement: null,
    action: null,
    currentTool: 'pointer',
    activeContextMenuObj: null,
    isDrawingWall: false,
    wallStartPos: { x: 0, y: 0 },
    previewWall: null,
    clipboard: null
};

// ESTA VERSÃO LÊ O DOM DIRETAMENTE, O QUE É CORRETO PARA UMA PÁGINA STANDALONE
export const dom = {
    canvasContainer: document.getElementById('canvas-container'),
    canvas: document.getElementById('canvas'),
    contextMenu: document.getElementById('context-menu'),
};

export function setState(newState) {
    state = { ...state, ...newState };
}

// ESTE É O PONTO DE ENTRADA CORRETO PARA UMA PÁGINA STANDALONE
window.addEventListener('DOMContentLoaded', () => {
    // 1. Inicializa todos os módulos
    initUI();
    initDataHandlers();
    initCanvas();
    initControls();

    // 2. Tenta carregar um projeto vindo do Dashboard (localStorage)
    try {
        const projectDataString = localStorage.getItem('currentProjectData');
        if (projectDataString) {
            const projectData = JSON.parse(projectDataString);
            if (projectData && projectData.walls) {
                rebuildCanvas(projectData);
            }
            // Limpa o localStorage para não carregar o mesmo projeto sempre
            localStorage.removeItem('currentProjectData');
        }
    } catch (error) {
        console.error("Erro ao carregar projeto do localStorage:", error);
        localStorage.removeItem('currentProjectData');
    }

    // 3. Aplica o transform inicial
    applyTransform();
    updateAllWallsAppearance();
});

