// js/data.js (VERSÃO STANDALONE REVERTIDA)
// Esta versão busca os elementos do DOM no topo,
// o que é correto para a página editor.html independente.

import { dom } from './main.js';
import { finalizeStandaloneWall } from './drawing.js';
import { updateAllWallsAppearance } from './canvas.js';
import { processImage } from './image-processor.js';

// Busca pelos elementos do DOM (correto no modo standalone)
const saveBtn = document.getElementById('saveBtn');
const loadBtn = document.getElementById('loadBtn');
const clearBtn = document.getElementById('clearBtn');
const fileInput = document.getElementById('fileInput');
const loadImageBtn = document.getElementById('loadImageBtn');
const imageFileInput = document.getElementById('imageFileInput');

export function initDataHandlers() {
    // Adiciona os listeners
    if (saveBtn) {
        saveBtn.addEventListener('click', saveData);
    }
    if (loadBtn && fileInput) {
        loadBtn.addEventListener('click', () => fileInput.click());
        fileInput.addEventListener('change', loadData);
    }
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            // CORREÇÃO: Removido 'confirm()'
            console.warn("Limpando o canvas. (confirm() removido)");
            dom.canvas.innerHTML = '';
        });
    }

    if (loadImageBtn && imageFileInput) {
        loadImageBtn.addEventListener('click', () => imageFileInput.click());
        imageFileInput.addEventListener('change', (event) => {
            const file = event.target.files[0];
            if (file) {
                // CORREÇÃO: Removido 'confirm()'
                console.log("Iniciando análise de imagem... (confirm() removido)");
                processImage(file);
            }
            if (imageFileInput) imageFileInput.value = ''; // Limpa para re-upload
        });
    }
}

function saveData() {
    const planData = {
        walls: [],
        gridSize: 20
    };

    document.querySelectorAll('.standalone-wall').forEach(wallEl => {
        const wallData = {
            id: wallEl.id,
            name: wallEl.dataset.name || '',
            left: wallEl.offsetLeft,
            top: wallEl.offsetTop,
            width: wallEl.offsetWidth,
            height: wallEl.offsetHeight,
            orientation: wallEl.dataset.orientation,
            objects: []
        };
         wallEl.querySelectorAll('.wall-object').forEach(objEl => {
            wallData.objects.push({
                type: objEl.classList.contains('door') ? 'door' : 'window',
                orientation: objEl.dataset.orientation,
                left: objEl.offsetLeft,
                top: objEl.offsetTop,
                width: objEl.offsetWidth,
                height: objEl.offsetHeight
            });
        });
        planData.walls.push(wallData);
    });

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(planData, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "planta-baixa.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
}

function loadData(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            rebuildCanvas(data);
        } catch (error) {
            console.error("Erro ao carregar o arquivo JSON:", error);
            // CORREÇÃO: Removido 'alert()'
            console.error("Não foi possível carregar o arquivo. Verifique se é um JSON válido.");
        }
    };
    reader.readAsText(file);
    if (fileInput) fileInput.value = ''; // Limpa para re-upload
}

// Esta função é chamada pelo main.js e pelo image-processor.js
export function rebuildCanvas(data) {
    if (!dom.canvas) {
         console.error("rebuildCanvas falhou: dom.canvas não está definido.");
         return;
    }
    
    dom.canvas.innerHTML = ''; // Limpa o canvas
    
    if (data.walls) {
        data.walls.forEach(wallData => {
            const wallEl = document.createElement('div');
            wallEl.dataset.orientation = wallData.orientation;
            wallEl.style.left = `${wallData.left}px`;
            wallEl.style.top = `${wallData.top}px`;
            wallEl.style.width = `${wallData.width}px`;
            wallEl.style.height = `${wallData.height}px`;
            
            const options = {
                id: wallData.id,
                name: wallData.name,
                objects: wallData.objects
            };

            dom.canvas.appendChild(wallEl);
            finalizeStandaloneWall(wallEl, options);
        });
    }
    updateAllWallsAppearance();
}