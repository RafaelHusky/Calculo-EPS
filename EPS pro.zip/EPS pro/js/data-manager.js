// js/data-manager.js - Gerencia os dados dos projetos (salvar e carregar)

const PROJECTS_STORAGE_KEY = 'constru_os_projects';

// Dados iniciais para o primeiro uso da aplicação
const defaultProjects = [
    { 
        id: 'proj-1666572600000', 
        name: 'Residencial Alfa', 
        lastModified: '20/10/2025', 
        status: 'Aprovado',
        schedule: '120',
        budget: '250000',
        gridSize: 20,
        walls: [
            { id: "wall-1", name: "Parede Frontal", left: 100, top: 100, width: 600, height: 20, orientation: 'horizontal', objects: [] },
            { id: "wall-2", name: "Parede Direita", left: 700, top: 100, width: 20, height: 400, orientation: 'vertical', objects: [] },
        ]
    },
];

/**
 * Busca todos os projetos salvos no localStorage.
 * Se não houver nenhum, salva e retorna os projetos padrão.
 * @returns {Array} A lista de projetos.
 */
export function getProjects() {
    let projects = localStorage.getItem(PROJECTS_STORAGE_KEY);
    if (!projects) {
        // Se for a primeira vez, salva os projetos padrão
        localStorage.setItem(PROJECTS_STORAGE_KEY, JSON.stringify(defaultProjects));
        return defaultProjects;
    }
    return JSON.parse(projects);
}

/**
 * Adiciona um novo projeto à lista e salva no localStorage.
 * @param {object} projectData - Os dados do novo projeto.
 */
export function addProject(projectData) {
    const projects = getProjects();
    projects.push(projectData);
    localStorage.setItem(PROJECTS_STORAGE_KEY, JSON.stringify(projects));
}

/**
 * Busca um projeto específico pelo seu ID.
 * @param {string} projectId - O ID do projeto a ser encontrado.
 * @returns {object|undefined} O objeto do projeto ou undefined se não for encontrado.
 */
export function getProjectById(projectId) {
    const projects = getProjects();
    return projects.find(p => p.id === projectId);
}