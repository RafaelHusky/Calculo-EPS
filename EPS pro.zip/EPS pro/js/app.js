// js/app.js - Cérebro da SPA
// 'budgeter', 'editor' e 'analyzer' foram REMOVIDOS deste arquivo,
// pois agora são janelas separadas.

const moduleScripts = {
    dashboard: './dashboard.js',
    'new-project-form': './new-project-form.js',
    settings: './settings.js'
    // 'budgeter' REMOVIDO DESTA LISTA
    // 'editor' e 'analyzer' REMOVIDOS DESTA LISTA
};

const viewStylesheets = {
    // 'editor' e 'analyzer' REMOVIDOS DESTA LISTA
};

const AppState = { currentProjectData: null };
let currentViewStylesheet = null; 

async function loadView(viewName) {
    const appContent = document.getElementById('app-content');
    if (!appContent) return;

    const hasContent = appContent.hasChildNodes();

    const loadNewContent = async () => {
        try {
            appContent.innerHTML = '<p class="text-gray-500 p-8 text-center">Carregando...</p>';

            // Limpa o CSS da view anterior
            if (currentViewStylesheet) {
                currentViewStylesheet.remove();
                currentViewStylesheet = null;
            }

            // Carrega o CSS da nova view
            if (viewStylesheets[viewName]) {
                const head = document.head;
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.type = 'text/css';
                link.href = viewStylesheets[viewName]; 
                head.appendChild(link);
                currentViewStylesheet = link; 
            }

            const response = await fetch(`views/${viewName}.html`);
            if (!response.ok) throw new Error(`View não encontrada: views/${viewName}.html`);

            appContent.innerHTML = await response.text();
            
            if (appContent.firstElementChild) {
                appContent.firstElementChild.style.animation = `fadeIn 0.4s ease-out both`;
            }

            if (moduleScripts[viewName]) {
                const module = await import(moduleScripts[viewName]);
                
                if (module && typeof module.init === 'function') {
                    setTimeout(() => {
                        module.init(AppState.currentProjectData); 
                    }, 0);
                }
            }
            updateActiveNavLink(viewName);
        } catch (error) {
            console.error('Erro ao carregar a view:', error);
            appContent.innerHTML = `<div class="p-8 text-center"><h2 class="text-2xl text-red-500">Erro</h2><p class="text-gray-400 mt-2">${error.message}</p></div>`;
        }
    };

    if (hasContent && appContent.firstElementChild) {
        appContent.firstElementChild.style.animation = `fadeOut 0.3s ease-out both`;
        setTimeout(loadNewContent, 300); 
    } else {
        loadNewContent();
    }
}

function updateActiveNavLink(viewName) {
    document.querySelectorAll('#sidebar .nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    let viewToActivate = viewName;

    // Removida a verificação do 'editor' e 'analyzer'.
    if (viewName === 'new-project-form') {
        viewToActivate = 'new-project-form';
    } 
    // Lógica para 'budgeter' REMOVIDA
    
    const activeLink = document.querySelector(`#sidebar .nav-link[data-view="${viewToActivate}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
}

window.navigateTo = (viewName, projectData = null) => {
    AppState.currentProjectData = projectData;
    loadView(viewName);
};

document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.addEventListener('click', (e) => {
            const navLink = e.target.closest('.nav-link');
            if (navLink && navLink.dataset.view) {
                e.preventDefault();
                AppState.currentProjectData = null; 
                loadView(navLink.dataset.view);
            }
        });
    }
    loadView('dashboard'); 
});