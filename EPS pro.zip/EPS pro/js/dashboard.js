// js/dashboard.js - Módulo do Painel (Refatorado para SPA)

// Importa os dados do seu "banco de dados" local
import { getProjects } from './data-manager.js';

/**
 * Função de inicialização que o app.js chamará.
 * @param {object | null} projectData - Dados do projeto (ignorado no dashboard).
 */
export function init(projectData) {
    console.log("Módulo Dashboard: init() foi chamado.");
    
    const createBtn = document.getElementById('create-new-work-btn');
    if (createBtn) {
        createBtn.addEventListener('click', () => {
            // Usa a função de navegação global para ir para o formulário
            window.navigateTo('new-project-form');
        });
    }

    // Renderiza a lista de projetos na tela
    renderProjectList();
}

/**
 * Busca os projetos do data-manager e os exibe na tela.
 */
function renderProjectList() {
    let projects = [];
    try {
        if (typeof getProjects === 'function') {
            projects = getProjects();
        } else {
            console.warn("'getProjects' não está definido ou não é uma função. Usando lista vazia.");
        }
    } catch (e) {
        console.error("Erro ao buscar projetos:", e);
    }
    
    const container = document.getElementById('project-list-container');
    if (!container) {
        console.error("Dashboard: Contêiner da lista de projetos não encontrado.");
        return;
    }
    
    container.innerHTML = ''; 

    if (projects.length === 0) {
        container.innerHTML = `<p class="text-gray-400 col-span-full">Nenhum projeto encontrado. Crie uma nova obra para começar.</p>`;
        return;
    }

    projects.forEach(project => {
        const card = document.createElement('div');
        card.className = "bg-gray-900/80 p-6 rounded-xl border border-gray-800 flex flex-col justify-between hover:border-blue-500 transition-colors duration-300";
        
        const statusClass = project.status === 'Aprovado' 
            ? 'bg-green-600/20 text-green-400' 
            : 'bg-yellow-600/20 text-yellow-400';
            
        const budget = project.budget ? parseFloat(project.budget).toLocaleString('pt-BR') : 'N/D';

        card.innerHTML = `
            <div>
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-bold text-white">${project.name}</h3>
                    <span class="text-xs font-medium py-1 px-3 rounded-full ${statusClass}">
                        ${project.status}
                    </span>
                </div>
                <p class="text-gray-400 text-sm mb-2">Última modificação: ${project.lastModified}</p>
                <div class="text-gray-400 text-sm">
                    <p>Prazo: ${project.schedule || 'N/D'} dias</p>
                    <p>Custo: R$ ${budget}</p>
                </div>
            </div>
            <div class="flex flex-col sm:flex-row gap-2 mt-6">
                <button data-action="open" data-id="${project.id}" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg text-sm transition-colors">Abrir Editor</button>
                <button data-action="analyze" data-id="${project.id}" class="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg text-sm transition-colors">Analisar</button>
                <button data-action="budget" data-id="${project.id}" class="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-4 rounded-lg text-sm transition-colors">Orçar</button>
            </div>
        `;
        
        container.appendChild(card);
    });

    container.addEventListener('click', handleCardClick);
}

/**
 * Manipulador de eventos para os cliques nos botões do card.
 * @param {Event} e - O evento de clique
 */
function handleCardClick(e) {
    const button = e.target.closest('button');
    if (!button || !button.dataset.action) return; 

    const action = button.dataset.action;
    const projectId = button.dataset.id;
    
    let project = null;
    try {
        if (typeof getProjects === 'function') {
             project = getProjects().find(p => p.id === projectId);
        }
    } catch (e) {
         console.error("Erro ao buscar projeto:", e);
    }

    if (!project) {
        console.error("Erro: Projeto não encontrado.");
        // Se o projeto não for encontrado, abre o orçamentador vazio
        if (action === 'budget') {
             window.open('budgeter.html', '_blank');
        }
        return;
    }

    // Navega para a view correta passando os dados do projeto
    switch (action) {
        case 'open':
            // Salva os dados para o editor.html ler
            localStorage.setItem('currentProjectData', JSON.stringify(project));
            window.open('editor.html', '_blank');
            break;
        case 'analyze':
            // Salva os dados para o analyzer.html ler
            localStorage.setItem('currentProjectData', JSON.stringify(project));
            window.open('analyzer.html', '_blank');
            break;
            
        case 'budget':
            // **MODIFICADO AQUI**
            // 1. Pega os dados da planta de dentro do objeto do projeto.
            //    Estou assumindo que eles estão em 'project.blueprintJson'.
            //    Se o nome da propriedade for outro (ex: 'planData'), altere aqui.
            const planData = project.blueprintJson; 
            
            if (planData) {
                // 2. Salva os dados da planta E o nome do projeto para o orçamentador ler
                const dataForBudgeter = {
                    name: project.name,
                    blueprintJson: planData 
                };
                localStorage.setItem('budgeterPlanData', JSON.stringify(dataForBudgeter));
            } else {
                console.warn("Este projeto não possui 'blueprintJson' para enviar ao orçamentador.");
                // Limpa qualquer dado antigo para garantir que o orçamentador abra vazio
                localStorage.removeItem('budgeterPlanData');
            }
            
            // 3. Abre o budgeter.html em uma nova aba
            window.open('budgeter.html', '_blank');
            break;
    }
}