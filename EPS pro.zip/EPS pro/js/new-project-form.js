// js/new-project-form.js - Corrigido para abrir editor em NOVA JANELA

import { addProject } from './data-manager.js';

export function init() {
    const startBtn = document.getElementById('start-project-btn');
    const cancelBtn = document.getElementById('cancel-project-btn');
    const nameInput = document.getElementById('project-name');
    const scheduleInput = document.getElementById('project-schedule');
    const budgetInput = document.getElementById('project-budget');
    const errorMsg = document.getElementById('project-name-error');

    if (cancelBtn) {
        cancelBtn.addEventListener('click', () => window.navigateTo('dashboard'));
    }

    if (startBtn) {
        startBtn.addEventListener('click', () => {
            const projectName = nameInput.value.trim();
            
            // Lógica de validação (sem alert)
            if (!projectName) {
                if (errorMsg) errorMsg.classList.remove('hidden'); 
                if (nameInput) {
                    nameInput.focus(); 
                    nameInput.classList.add('border-red-500', 'focus:ring-red-500'); 
                }
                return;
            } else {
                 if (errorMsg) errorMsg.classList.add('hidden'); 
                 if (nameInput) {
                    nameInput.classList.remove('border-red-500', 'focus:ring-red-500'); 
                 }
            }

            const currentDate = new Date();
            const formattedDate = `${currentDate.getDate().toString().padStart(2, '0')}/${(currentDate.getMonth() + 1).toString().padStart(2, '0')}/${currentDate.getFullYear()}`;

            const newProjectData = {
                id: `proj-${Date.now()}`,
                name: projectName,
                lastModified: formattedDate,
                status: 'Em Análise',
                schedule: scheduleInput.value,
                budget: budgetInput.value,
                gridSize: 20,
                walls: [],
            };

            // 1. Salva o novo projeto no "banco de dados"
            addProject(newProjectData);

            // --- ESTA É A MUDANÇA (Reversão) ---
            // 2. Salva os dados no localStorage para a nova janela ler
            localStorage.setItem('currentProjectData', JSON.stringify(newProjectData));
            
            // 3. Abre editor.html em uma nova aba
            window.open('editor.html', '_blank');
            
            // 4. Navega de volta ao dashboard (para ver o projeto na lista)
            window.navigateTo('dashboard');
            // --- FIM DA MUDANÇA ---
        });
    }
}

